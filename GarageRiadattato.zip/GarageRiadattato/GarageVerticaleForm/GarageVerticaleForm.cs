﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using TwinCAT.Ads;

namespace GarageVerticaleForm
{

    public partial class GarageVerticaleForm : Form
    {
        private static Point INITPOINT = new Point(282, 614);
        private Random r = new Random();
        private Boolean inPosizione = false;
        private int durata, spostamento, delta, movement, piano = 3, initAGVX = 277, initLift = 684, numeroCasuale;
        private int x, y;  // rispettivamente livello e slot correnti
        int cont = 0;
        private Button riparaGuasto;
        private Point pointPark, p;
        private PictureBox[,] parksLights = new PictureBox[4, 4];
        private PictureBox[,] arrayParks = new PictureBox[4, 4];
        private Point[,] arrayPoint = new Point[4, 4];
        private Dictionary<Point, PictureBox> ParksMap = new Dictionary<Point, PictureBox>();
        private PictureBox car, carU, pictureAGVplatform, pictureArm1, pictureArm2, pictureStaffa1, pictureStaffa2 = null;
        private PictureBox currentPark;
        private LinkedList<PictureBox> CarsEntranceList = new LinkedList<PictureBox>();
        private LinkedList<PictureBox> CarsLiftList = new LinkedList<PictureBox>();
        private LinkedList<PictureBox> CarsExitList = new LinkedList<PictureBox>();
        private LinkedList<PictureBox> MacchinaInExit = new LinkedList<PictureBox>();
        private LinkedList<Point> ParksToExitList = new LinkedList<Point>();
        private LinkedList<PictureBox> MacchinaInEntrance = new LinkedList<PictureBox>(); //macchina in posizione per essere caricata
        private String[] arrayImages = new String[] { @"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car1.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car2.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car3.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car4.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car5.png" };
        private String[] arrayImagesl = new String[] { @"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car1l.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car2l.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car3l.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car4l.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car5l.png" };
        private String[] arrayImagesu = new String[] { @"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car1u.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car2u.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car3u.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car4u.png",
@"C:\Users\augus\OneDrive\Desktop\PROGETTO RESPA\GarageRiadattato\GarageVerticaleForm\car5u.png" };

        // VARIABILI SENSORI
        private TextBox[] SensoriSlot = new TextBox[4];
        private TextBox[] SensoriLivelli = new TextBox[4];
        private Boolean[,] SensoriPeso = new Boolean[4, 4];
        

        

        /* --- Variabili per ADS client --- */
        // ADS Client
        private TcAdsClient tcClient;
        // Array for PLC variables
        private int[] hConnect;
        // ADS Stream , based on the specific region of a byte  array
        private AdsStream dataStream;
        private AdsBinaryReader binRead;
        // Numero di variabili di tipo boolean
        private int NUM_ELEMENTS_BOOL = 44; 
        // Numero di variabili di tipo TIME
        private int NUM_ELEMENTS_TIME = 1;
        // Numero di variabili di tipo int
        private int NUM_ELEMENTS_INT = 2;
        private int[] hvar_name;

        // Array of string elements for read / write data handle by variable names

        private string[] dataPLC = { "MAIN.ComandoSali", "MAIN.ComandoCarica" ,
       "MAIN.ComandoVaiSx" , "MAIN.ComandoVaiDx" , "MAIN.ComandoScarica" , 
       "MAIN.ComandoRiposizionaLift" , "MAIN.ComandoPosizionaMacchina" ,
       "MAIN.ComandoRiposizionaAGV" , "MAIN.ComandoPortaViaMacchina" ,
       "MAIN.SensoreStart" , "MAIN.ComandoAllarme" , "MAIN.SenPos1" ,
       "MAIN.SenPos2" , "MAIN.SenPos3" , "MAIN.SenPos4" , "MAIN.SenPeso01" ,
       "MAIN.SenPeso02" , "MAIN.SenPeso03" , "MAIN.SenPeso04" , "MAIN.SenPeso11" ,
       "MAIN.SenPeso12" , "MAIN.SenPeso13" , "MAIN.SenPeso14" , "MAIN.SenPeso21" ,
       "MAIN.SenPeso22" , "MAIN.SenPeso23" , "MAIN.SenPeso24" , "MAIN.SenPeso31" ,
       "MAIN.SenPeso32" , "MAIN.SenPeso33" , "MAIN.SenPeso34" ,  
       "MAIN.SL0" , "MAIN.SL1" , "MAIN.SL2" , "MAIN.SL3" ,  
       "MAIN.SensoreReset" , "MAIN.SensoreMacchinaInAGV" , "MAIN.SensoreLiftInPos" ,
       "MAIN.SensoreAgvInPos" , "MAIN.SensoreMacchinaInEntrance" , "MAIN.SensoreAgvReady" ,
        "MAIN.livello" , "MAIN.slot" , "MAIN.SensoreRichiestaScarico" , "MAIN.DeviScaricare"
        , "MAIN.TimeWatchDog" , "MAIN.SensoreParkFull"};

        public GarageVerticaleForm()
        {
            InitializeComponent();
        }

        /*  Inizializzazione di variabili e textBox */

        private void GarageVerticaleForm_Load(object sender, EventArgs e)
        {
            x = 0;
            y = 0;
            p = new Point(0, 0);
            durata = 5000;
            spostamento = 500;
            delta = MasterTimer.Interval;
            movement = 2;                           //(int)(spostamento * delta / durata);
            textStart.Text = "0";
            textReset.Text = "0";
            textStop.Text = "0";
            textGuasto.Text = "0";
            textParkFull.Text = "0";
            textScaricoOn.Text = "1";
            textScaricoOff.Text = "0";
            textMacchinaInEntrance.Text = "0";

            SensoriLivelli = new TextBox[4] { textSensoreLivello0, textSensoreLivello1, textSensoreLivello2, textSensoreLivello3 };
            SensoriSlot = new TextBox[4] { textSensoreSlot1, textSensoreSlot2, textSensoreSlot3, textSensoreSlot4 };

            arrayPoint = new Point[4, 4];

            parksLights = new PictureBox[4, 4] {   
                 { Park01, Park02, Park03, Park04 },
                 { Park11, Park12, Park13, Park14 },
                 { Park21, Park22, Park23, Park24 },
                 { Park31, Park32, Park33, Park34 } };
            

            arrayParks = new PictureBox[4, 4] {
                { pictureBox0A, pictureBox0B, pictureBox0C, pictureBox0D },
                { pictureBox1A, pictureBox1B, pictureBox1C, pictureBox1D },
                { pictureBox2A, pictureBox2B, pictureBox2C, pictureBox2D },
                { pictureBox3A, pictureBox3B, pictureBox3C, pictureBox3D } };

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    parksLights[i, j].BackColor = Color.Lime;

                    /* Costruisco le coordinate dei punti di riferimento per il parcheggio */
                    arrayPoint[i, j] = new Point(arrayParks[i, j].Left - 35, arrayParks[i, j].Top - 60);
                }
            }
        } 


        /*  MASTER TIMER  */

        private void MasterTimer_Tick(object sender, EventArgs e)
        {
           
            currentPark = null;
            int valueZ = 28;
            if (pictureArm1 != null) valueZ = pictureArm1.Top;
            labelPositions.Text = "LIFT: (" + pictureLift.Left + ", " + pictureLift.Bottom + ");" + " AGV: (" + pictureAgv.Left + ", " + pictureAgv.Bottom + ", " + valueZ + ").";
            durata = 5000;
            spostamento = 500;
            delta = MasterTimer.Interval;
            PictureBox thisCar = null;
            PictureBox CarToLoad = null;       // macchina da parcheggiare

            sendToBack();                     // per avere l'ascensore in primo piano
           
            aggiornaParksLights();

            aggiornaSensori();


             /*******************                        RICHIEDI SCARICO                    *******************/


            if (CarsExitList.First != null && MacchinaInExit.First == null)
                aggiornaScaricoPLC();


            /*******************                       GATE ENTRANCE ON/OFF                   *******************/


            if (pictureLift.Top==initLift && MacchinaInEntrance.First==null)
                GateEntrance.BackColor = System.Drawing.Color.Lime;
            else GateEntrance.BackColor = System.Drawing.Color.Red;


            if (CarsLiftList.First != null)      // Prende riferimento macchina da parcheggiare
            {
                 thisCar = CarsLiftList.First.Value;
                 CarToLoad = CarsLiftList.First.Value;
            } 
            
        }                 // MASTER TIMER END






        /******************                          CORPO CODICE                           ******************/


        private void aggiornaSensori()
         {
               
                if (MacchinaInEntrance.First != null)
                textMacchinaInEntrance.Text = "1";
            else textMacchinaInEntrance.Text = "0";


            if (CarsLiftList.First != null)
            {
                if (CarsLiftList.First.Value.Left <=INITPOINT.X && CarsLiftList.First.Value.Left >= (INITPOINT.X-1)) // MACCHINA IN AGV
                    textMacchinaInAGV.Text = "1";
                else textMacchinaInAGV.Text = "0";
            }

          
            if (pictureLift.Top == initLift)
                textLiftInPos.Text = "1";
             else textLiftInPos.Text = "0";
            if (pictureAgv.Left == initAGVX)
                textAgvInPos.Text = "1";
            else textAgvInPos.Text = "0";





        }

       // METODI DI ATTUAZIONE DEI COMANDI

        private void sali(PictureBox thisCar)
        {
            pictureLift.Top -= movement;
            if (thisCar!=null) thisCar.Top -= movement;
            pictureAgv.Top -= movement;
        }

        private void riposizionaLift(PictureBox thisCar)
        {
            if (pictureLift.Top != initLift)
            {
                pictureLift.Top += movement;
                thisCar.Top += movement;
                pictureAgv.Top += movement;
            }
        }

        private void riposizionaLift()
        {
            if (pictureLift.Top != initLift)
            {
                pictureLift.Top += movement;
                pictureAgv.Top += movement;
            }
        }


        private void vaiSx(PictureBox thisCar)
        {
            thisCar.Left -= movement - 1;
            pictureAgv.Left -= movement - 1;
        }

        private void vaiSx()
        {

            pictureAgv.Left -= movement - 1;
        }


        private void vaiDx(PictureBox thisCar)
        {

            thisCar.Left += movement-1;
            pictureAgv.Left += movement-1;
        }

        private void vaiDx()
        {

            pictureAgv.Left += movement-1;
        }

        private void carica(PictureBox thisCar) //AGV parcheggia la macchina
        {
            if (carU == null)

            {

                for (int i = 0; i < 5; i++)
                {
                    if (thisCar.ImageLocation == arrayImages[i])
                    {
                        carU = new PictureBox
                        {

                            SizeMode = PictureBoxSizeMode.Zoom,
                            Size = new Size(90, 110),
                            ImageLocation = arrayImagesu[i],
                        };

                        TimerLoadAGV.Enabled = true; 

                    }

                }
            }
        }

        private void scarica(PictureBox thisCar) //AGV preleva la macchina
        {
            if (carU == null)
            {

                for (int i = 0; i < 5; i++)
                {
                    if (thisCar.ImageLocation == arrayImages[i])
                    {
                        carU = new PictureBox
                        {

                            SizeMode = PictureBoxSizeMode.Zoom,
                            Size = new Size(90, 110),
                            ImageLocation = arrayImagesu[i],
                        };

                        TimerUnloadAGV.Enabled = true;

                    }

                }
            }
        }



        private void riposizionaAGV()
        {
            /* while (pictureAgv.Left != initAGVX)
             {*/
            if (pictureAgv.Left != initAGVX)
            {
                if ((pictureAgv.Left < initAGVX))
                {
                    vaiDx();
                }
                else
                {
                    vaiSx();
                }

            }
        }

        private void riposizionaAGV(PictureBox car)
        {
            /* while (pictureAgv.Left != initAGVX)
             {*/
            if (pictureAgv.Left != initAGVX)
            {
                if ((pictureAgv.Left < initAGVX))
                {
                    vaiDx(car);
                }
                else
                {
                    vaiSx(car);
                }
            }
            

            
        }



        //}





        private void removeSimulation(PictureBox thisCar) //rimuove simulazione carica/scarico

        {
            pictureSensor.BackColor = System.Drawing.Color.Black;
            simulationAGV.Controls.Remove(carU);
            simulationAGV.Controls.Remove(pictureAGVplatform);
            simulationAGV.Controls.Remove(pictureArm1);
            simulationAGV.Controls.Remove(pictureArm2);
            simulationAGV.Controls.Remove(pictureStaffa1);
            simulationAGV.Controls.Remove(pictureStaffa2);
            pictureAGVplatform = null;
            pictureArm1 = null;
            pictureArm2 = null;
            pictureStaffa1 = null;
            pictureStaffa2 = null;
            carU = null;
            //textLift.Text = "0";
            inPosizione = false;
        }

        private void posizionaMacchina()
        {
            //if (CarsLiftList.First != null) {

            //CarsEntranceList.RemoveFirst(); //aggiorno lista coda macchine
            CarsLiftList.AddFirst(MacchinaInEntrance.First.Value); //la macchina sta andando sull'ascensore
            MacchinaInEntrance.RemoveFirst(); //la macchina non è più in posizione per essere posizionata


            TimerPosizionaSuLift.Enabled = true;
        }
        
        private void portaViaMacchina()
        {

            if (MacchinaInExit.First != null)
            {
                if (MacchinaInExit.First.Value.Right > simulation.Left)
                {
                    MacchinaInExit.First.Value.Left -= movement + 2;
                    timerPortaViaMacchina.Enabled = true;
                }
                else
                {
                    simulation.Controls.Remove(MacchinaInExit.First.Value); MacchinaInExit.RemoveFirst();
                    timerPortaViaMacchina.Enabled = false;
                }
            }

        }

        // LETTURA COMANDI DAL PLC

        private void textComandoVaiDx_TextChanged(object sender, EventArgs e)
        {
            if (textComandoVaiDx.Text == "True")
            {
                timerSensoriSlot.Enabled = true;
                timerVaiDx.Enabled = true;
            }
            else
            {

                timerVaiDx.Enabled = false;
            }
        }



        private void textComandoVaiSx_TextChanged(object sender, EventArgs e)
        {
            if (textComandoVaiSx.Text == "True")
            {
                timerSensoriSlot.Enabled = true;
                timerVaiSx.Enabled = true;
            }
            else
            {

                timerVaiSx.Enabled = false;
            }
        }



        private void textComandoRiposizionaAgv_TextChanged(object sender, EventArgs e)
        {
            if (textComandoRiposizionaAgv.Text == "True")
            {

                TimerRiposizionaAGV.Enabled = true;
            }
            else
            {

                TimerRiposizionaAGV.Enabled = false;
            }
        }



        private void textComandoPosizionaMacchina_TextChanged(object sender, EventArgs e)
        {
            if (textComandoPosizionaMacchina.Text == "True")
                posizionaMacchina();
        }



        private void textComandoCarica_TextChanged(object sender, EventArgs e)
        {
            if (textComandoCarica.Text.Equals("True"))
                carica(CarsLiftList.First.Value);
        }


        private void textComandoSali_TextChanged(object sender, EventArgs e)
        {
            if (textComandoSali.Text == "True")
            {
                timerSali.Enabled = true;
            }
        }


        private void textComandoRiposizionaLift_TextChanged(object sender, EventArgs e)
        {
            if (textComandoRiposizionaLift.Text == "True")
            {
                timerSensoriSlot.Enabled = false;
                tcClient.WriteAny(hvar_name[40], false);//metto SensoreAgvReady a false
                timerRiposizionaLift.Enabled = true;
            }
            else
            {
                timerRiposizionaLift.Enabled = false;
            }
        }

        

        private void textComandoPortaViaMacchina_TextChanged(object sender, EventArgs e)
        {
            if (textComandoPortaViaMacchina.Text == "True")
            {
                tcClient.WriteAny(hvar_name[36], false); //SensoreMacchinaInAGV
                tcClient.WriteAny(hvar_name[43], false); //resetto sensoreRichiestaScarico
                timerPortaViaMacchina.Enabled = true;
            }
        }



        private void textComandoScarica_TextChanged(object sender, EventArgs e)
        {
            if (textComandoScarica.Text == "True")
                scarica(CarsExitList.First.Value);
        }


        // TIMER COMANDI


        /* TIMER SALI */
        private void timerSali_Tick(object sender, EventArgs e)
        {
            if (textComandoSali.Text == "True") 
            {
                if (textDeviScaricare.Text == "False")
                {
                    sali(CarsLiftList.First.Value);
                }
                else
                {
                    sali(null);
                }

                //AGGIORNA SENSORI LIVELLO
                if (arrayPoint[cont, 0].Y + 67 <= pictureLift.Top && arrayPoint[cont, 0].Y + 68 >= pictureLift.Top)
                {
                    
                    SensoriLivelli[cont].Text = "1";
                    if (cont < 3)
                    {
                        cont++;
                    }
                }
                timerSali.Enabled = true;
            }


            else  
            {
                for (int i = 0; i < 4; i++)
                {
                    SensoriLivelli[i].Text = "0";
                }
                cont = 0;
                timerSali.Enabled = false;
            }
        }


        private void TimerRiposizionaAGV_Tick(object sender, EventArgs e)
        {
            if (textDeviScaricare.Text == "True")
                riposizionaAGV(MacchinaInExit.First.Value);
            else
                riposizionaAGV();
            TimerRiposizionaAGV.Enabled = true;
        }

        private void timerRiposizionaLift_Tick(object sender, EventArgs e)
        {
            if (textDeviScaricare.Text == "True" && textComandoAllarme.Text != "True") // MODIFICA 1
                riposizionaLift(MacchinaInExit.First.Value);
            else
                riposizionaLift();
            timerRiposizionaLift.Enabled = true;
        }



        private void timerVaiDx_Tick(object sender, EventArgs e)
        {
            if (textDeviScaricare.Text == "True")
                vaiDx();
            else
                vaiDx(CarsLiftList.First.Value);
            timerVaiDx.Enabled = true;
        }



        private void timerVaiSx_Tick(object sender, EventArgs e)
        {
            if (textDeviScaricare.Text == "True")
                vaiSx();
            else
                vaiSx(CarsLiftList.First.Value);
            timerVaiSx.Enabled = true;
        }



        private void timerPortaViaMacchina_Tick(object sender, EventArgs e)
        {
            portaViaMacchina();
         }


        private void TimerPosizionaSuLift_Tick(object sender, EventArgs e)
        {
            if (CarsLiftList.First.Value.Left > INITPOINT.X && pictureLift.Location.Y == initLift)
            {
                CarsLiftList.First.Value.Left -= movement;
                TimerPosizionaSuLift.Enabled = true;
            }
            else
            {
                for (int i = 0; i < 5; i++)
                {
                    if (CarsLiftList.First.Value.ImageLocation == arrayImagesl[i])
                    {
                        CarsLiftList.First.Value.ImageLocation = arrayImages[i];
                        CarsLiftList.First.Value.Size = new Size(80, 60);
                    }
                }
                TimerPosizionaSuLift.Enabled = false;
            }
        }


        // TIMER SENSORI SLOT

        private void timerSensoriSlot_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                if (arrayPoint[0, i].X - 2 >= pictureAgv.Left && arrayPoint[0, i].X - 3 <= pictureAgv.Left)
                {
                    SensoriSlot[i].Text = "1";
                    tcClient.WriteAny(hvar_name[11 + i], true);
                }
                else
                {
                    if (SensoriSlot[i].Text == "1")
                    {
                        tcClient.WriteAny(hvar_name[11 + i], false);
                        SensoriSlot[i].Text = "0";
                    }

                }
            }
            if (timerSensoriSlot.Enabled != false)
                timerSensoriSlot.Enabled = true;
        }



        // TEXT_BOX SENSORI



        private void textMacchinaInEntrance_TextChanged(object sender, EventArgs e)
        {
            if (hvar_name != null)
            {
                if (textMacchinaInEntrance.Text.Equals("1")) tcClient.WriteAny(hvar_name[39], true);
                else tcClient.WriteAny(hvar_name[39], false);
            }
        }



        private void textMacchinaInAGV_TextChanged(object sender, EventArgs e)
        {
            if (textMacchinaInAGV.Text.Equals("1")) tcClient.WriteAny(hvar_name[36], true);
            else tcClient.WriteAny(hvar_name[36], false);
        }



        private void textLiftInPos_TextChanged(object sender, EventArgs e)
        {
            if (textLiftInPos.Text.Equals("1")) tcClient.WriteAny(hvar_name[37], true);
            else tcClient.WriteAny(hvar_name[37], false);
        }



        private void textAgvInPos_TextChanged(object sender, EventArgs e)
        {
            if (textAgvInPos.Text.Equals("1")) tcClient.WriteAny(hvar_name[38], true);
            else tcClient.WriteAny(hvar_name[38], false);
        }



        private void textSensoreLivello0_TextChanged(object sender, EventArgs e)
        {
            if (textSensoreLivello0.Text.Equals("1"))
            {
                tcClient.WriteAny(hvar_name[31], true);
                x = 0;
                pointPark = arrayPoint[x, y];
            }

            else
            {
                if (textSensoreLivello0.Text == "0")
                    tcClient.WriteAny(hvar_name[31], false);
            }

        }



        private void textSensoreLivello1_TextChanged(object sender, EventArgs e)
        {
            if (textSensoreLivello1.Text.Equals("1"))
            {
                tcClient.WriteAny(hvar_name[32], true);
                x = 1;
                pointPark = arrayPoint[x, y];
            }

            else tcClient.WriteAny(hvar_name[32], false);

        }



        private void textSensoreLivello2_TextChanged(object sender, EventArgs e)
        {
            if (textSensoreLivello2.Text.Equals("1"))
            {
                tcClient.WriteAny(hvar_name[33], true);
                x = 2;
                pointPark = arrayPoint[x, y];
            }

            else tcClient.WriteAny(hvar_name[33], false);

        }



        private void textSensoreLivello3_TextChanged(object sender, EventArgs e)
        {
            if (textSensoreLivello3.Text.Equals("1"))
            {
                tcClient.WriteAny(hvar_name[34], true);
                x = 3;
                pointPark = arrayPoint[x, y];
            }

            else tcClient.WriteAny(hvar_name[34], false);
        }


        private void textSensoreSlot1_TextChanged(object sender, EventArgs e)
        {
            if (textSensoreSlot1.Text.Equals("1"))
            {
                tcClient.WriteAny(hvar_name[11], true);
                y = 0;
                pointPark = arrayPoint[x, y];
            }
            else
                tcClient.WriteAny(hvar_name[11], false);

        }


        private void textSensoreSlot2_TextChanged(object sender, EventArgs e)
        {
            if (textSensoreSlot2.Text.Equals("1"))
            {
                tcClient.WriteAny(hvar_name[12], true);
                y = 1;
                pointPark = arrayPoint[x, y];
            }
            else
                tcClient.WriteAny(hvar_name[12], false);
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            if (textStop.Text == "0")
            {
                MasterTimer.Enabled = false;
                TimerCausalEntrance.Enabled = false;
                TimerRichiestaScarico.Enabled = false;
                TimerPosizionaSuLift.Enabled = false;
                timerSali.Enabled = false;
                timerVaiDx.Enabled = false;
                timerVaiSx.Enabled = false;
                TimerLoadAGV.Enabled = false;
                TimerUnloadAGV.Enabled = false;
                TimerRiposizionaAGV.Enabled = false;
                timerRiposizionaLift.Enabled = false;
                timerPortaViaMacchina.Enabled = false;
                textStop.Text = "1";
                textStart.Text = "0";
            }
            
        }

        private void buttonGuastoAscensore_Click(object sender, EventArgs e)
        {
            if (textGuasto.Text == "0" && textDeviScaricare.Text=="True")
                textGuasto.Text = "1";
        }

        private void textGuasto_TextChanged(object sender, EventArgs e)
        {
            if (textGuasto.Text == "1")
                timerSali.Enabled = false;
        }

        private void buttonRipara_Click(object sender, EventArgs e)
        {
            if (textGuasto.Text == "1")
                textGuasto.Text = "0";
        }

        

        private void textParkFull_TextChanged(object sender, EventArgs e)
        {
            if (hvar_name != null)
            { 
                if (textParkFull.Text == "1")
                    tcClient.WriteAny(hvar_name[46], true);
                else
                    tcClient.WriteAny(hvar_name[46], false);
            }

        }

        private void buttonOn_Click(object sender, EventArgs e)
        {
            if (textScaricoOn.Text == "0" && textStart.Text=="1")
            {
                TimerRichiestaScarico.Enabled = true;
                textScaricoOff.Text = "0";
                textScaricoOn.Text = "1";
            }
        }

        private void buttonOff_Click(object sender, EventArgs e)
        {
            if (textScaricoOff.Text == "0" && textStart.Text == "1")
            {
                TimerRichiestaScarico.Enabled = false;
                textScaricoOff.Text = "1";
                textScaricoOn.Text = "0";
            }
        }

        private void TimerDelay_Tick(object sender, EventArgs e)
        {
            TimerDelay.Enabled = false;
        }

        private void textSensoreSlot3_TextChanged(object sender, EventArgs e)
        {
            if (textSensoreSlot3.Text.Equals("1"))
            {
                tcClient.WriteAny(hvar_name[13], true);
                y = 2;
                pointPark = arrayPoint[x, y];
            }
            else
                tcClient.WriteAny(hvar_name[13], false);
        }


        private void textSensoreSlot4_TextChanged(object sender, EventArgs e)
        {
            if (textSensoreSlot4.Text.Equals("1"))
            {
                tcClient.WriteAny(hvar_name[14], true);
                y = 3;
                pointPark = arrayPoint[x, y];
            }
            else
                tcClient.WriteAny(hvar_name[14], false);
        }

     

        // CONNESSIONE AL PLC


        private void buttonConnection_Click(object sender, EventArgs e)
        {
            // Generate Instance of TcAdsClient class
            tcClient = new TcAdsClient();
            // Connection to target PLC on Localhost on port 851
            tcClient.Connect("127.0.0.1.1.1", 851);
            // Stream for ADS communication for reading
            // 15 is the amount of bytes to read / write
            dataStream = new AdsStream(NUM_ELEMENTS_BOOL +
            NUM_ELEMENTS_TIME * 4);
            // ASCII Encoding setting , to read string format
            binRead = new AdsBinaryReader(dataStream);
            // Create a stream of 8 data elements by
            // variable name and type
            hConnect = new int[NUM_ELEMENTS_BOOL +
            NUM_ELEMENTS_TIME + NUM_ELEMENTS_INT];
            try
            {
                /*AddDeviceNotification(stringVariableName,
               AdsStreamdataStream, intoffset, intlength,
AdsTransModetransMode, intcycleTime,
intmaxDelay, objectuserData)*/
                /* Consente di scrivere nelle opportune caselle di
                testo i valori che vengono letti dal PLC */


                hConnect[0] = tcClient.AddDeviceNotification(
                dataPLC[0], dataStream, 0, 1, AdsTransMode.
                OnChange, 100, 0, textComandoSali);

                hConnect[1] = tcClient.AddDeviceNotification(
                dataPLC[1], dataStream, 1, 1, AdsTransMode.
                OnChange, 100, 0, textComandoCarica);

                hConnect[2] = tcClient.AddDeviceNotification(
                dataPLC[2], dataStream, 2, 1, AdsTransMode.
                OnChange, 100, 0, textComandoVaiSx);

                hConnect[3] = tcClient.AddDeviceNotification(
                dataPLC[3], dataStream, 3, 1, AdsTransMode.
                OnChange, 100, 0, textComandoVaiDx);

                hConnect[4] = tcClient.AddDeviceNotification(
                dataPLC[4], dataStream, 4, 1, AdsTransMode.
                OnChange, 100, 0, textComandoScarica);

                hConnect[5] = tcClient.AddDeviceNotification(
                 dataPLC[5], dataStream, 5, 1, AdsTransMode.
                 OnChange, 100, 0, textComandoRiposizionaLift);

                hConnect[6] = tcClient.AddDeviceNotification(
                 dataPLC[6], dataStream, 6, 1, AdsTransMode.
                 OnChange, 100, 0, textComandoPosizionaMacchina);

                hConnect[7] = tcClient.AddDeviceNotification(
                 dataPLC[7], dataStream, 7, 1, AdsTransMode.
                 OnChange, 100, 0, textComandoRiposizionaAgv);

                hConnect[8] = tcClient.AddDeviceNotification(
                 dataPLC[8], dataStream, 8, 1, AdsTransMode.
                 OnChange, 100, 0, textComandoPortaViaMacchina);

                hConnect[44] = tcClient.AddDeviceNotification(
                 dataPLC[44], dataStream, 9, 1, AdsTransMode.
                 OnChange, 100, 0, textDeviScaricare);

                hConnect[10] = tcClient.AddDeviceNotification(
                 dataPLC[10], dataStream, 10, 1, AdsTransMode.
                 OnChange, 100, 0, textComandoAllarme);

                hConnect[45] = tcClient.AddDeviceNotification(
                 dataPLC[45], dataStream, 11, 4, AdsTransMode.
                 OnChange, 100, 0, textTimeWatchDog);

                





                tcClient.AdsNotification += new
    AdsNotificationEventHandler(OnNotification);
                textConnection.Text = " Connection ␣ Established !!! ";
            }
            catch (Exception err)
            {
                textConnection.Text = err.Message.ToString();
            }
            // Generate handles for writing by name

            hvar_name = new int[NUM_ELEMENTS_BOOL +
        NUM_ELEMENTS_TIME + NUM_ELEMENTS_INT];
            for (int i = 0; i < NUM_ELEMENTS_BOOL +
            NUM_ELEMENTS_TIME + NUM_ELEMENTS_INT; i++)
            {
                hvar_name[i] = tcClient.CreateVariableHandle(
                dataPLC[i]);
            }
        }


        // Function for read the ADS variables and display within textBox

        private void OnNotification(object sender, AdsNotificationEventArgs e)

        {
            DateTime time = DateTime.FromFileTime(e.
            TimeStamp);
            e.DataStream.Position = e.Offset;
            string strValue = "";
            if (e.NotificationHandle == hConnect[0])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[1])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[2])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[3])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[4])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[5])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[6])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[7])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[8])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[44])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[10])
                strValue = binRead.ReadBoolean().
                ToString();
            else if (e.NotificationHandle == hConnect[45])
                strValue = binRead.ReadInt32().
                ToString();
            var typeObj = e.UserData.GetType();
            var BoxObject = ((TextBox)e.UserData);
            ((TextBox)e.UserData).Invoke(new Action(() =>
   ((TextBox)e.UserData).Text = String.Format
   (strValue)));

        }



        // TIMER UNLOAD AGV

        private void TimerUnloadAGV_Tick(object sender, EventArgs e) //cambiato
        {
            if (pictureAGVplatform == null)
            {
                if (pointPark.X > initAGVX)
                {
                    p = new Point(-140, 30);
                }
                if (pointPark.X < initAGVX)
                {
                    p = new Point(170, 30);
                }

                pictureAGVplatform = new PictureBox
                {
                    Location = p,
                    BackColor = System.Drawing.Color.Blue,
                    Size = new Size(140, 140),

                };
                pictureArm1 = new PictureBox
                {
                    Size = new Size(20, 140),
                    BackColor = System.Drawing.Color.Gray,
                };
                pictureArm2 = new PictureBox
                {
                    Size = new Size(20, 140),
                    BackColor = System.Drawing.Color.Gray,
                };
                pictureStaffa1 = new PictureBox
                {
                    Size = new Size(20, 120),
                    BackColor = System.Drawing.Color.DarkGray,
                };
                pictureStaffa2 = new PictureBox
                {
                    Size = new Size(20, 120),
                    BackColor = System.Drawing.Color.DarkGray,
                };

                carU.Left = 37;
                carU.Top = pictureSensor.Top;
                pictureArm1.Top = 30;
                pictureArm1.Left = pictureAGVplatform.Left + 20;
                pictureArm2.Top = 30;
                pictureArm2.Left = pictureAGVplatform.Right - 40;
                pictureStaffa1.Top = pictureAGVplatform.Top + 30;
                pictureStaffa1.Left = pictureAGVplatform.Left + 20;
                pictureStaffa2.Top = pictureAGVplatform.Top + 30;
                pictureStaffa2.Left = pictureAGVplatform.Right - 40;
                pictureSensor.BackColor = System.Drawing.Color.Red;
                this.simulationAGV.Controls.Add(pictureAGVplatform);
                this.simulationAGV.Controls.Add(pictureArm1);
                this.simulationAGV.Controls.Add(pictureArm2);
                this.simulationAGV.Controls.Add(pictureStaffa1);
                this.simulationAGV.Controls.Add(pictureStaffa2);
                this.simulationAGV.Controls.Add(carU);
                carU.BringToFront();
                picturePark.SendToBack();
                pictureAGVplatform.SendToBack();

            }
            if (carU.Left == 37 && pictureAGVplatform.Left > 12 && pictureArm1.Top >= 30)
            {
                pictureAGVplatform.Left -= movement;
                pictureArm1.Left -= movement;
                pictureArm2.Left -= movement;
                pictureStaffa1.Left -= movement;
                pictureStaffa2.Left -= movement;
                TimerUnloadAGV.Enabled = true;
            }

            if (carU.Left == 37 && pictureAGVplatform.Left < 12 && pictureArm1.Top >= 30)
            {
                pictureAGVplatform.Left += movement;
                pictureArm1.Left += movement;
                pictureArm2.Left += movement;
                pictureStaffa1.Left += movement;
                pictureStaffa2.Left += movement;
                TimerUnloadAGV.Enabled = true;
            }


            if (carU.Left == 37 && pictureAGVplatform.Left == 12 && pictureArm1.Top >= 30)
            {
                if (pictureArm1.Top < carU.Top)
                {
                    pictureArm2.Top += movement * 2;
                    pictureArm1.Top += movement * 2;
                    TimerUnloadAGV.Enabled = true;
                }

            }

            if (pictureArm1.Top >= carU.Top && pictureArm1.Top > 30)
            {
                pictureArm2.Top -= movement * 5;
                pictureArm1.Top -= movement * 5;
                carU.Top -= movement * 5;
                TimerUnloadAGV.Enabled = true;
            }


            if (pictureArm1.Top < 30 && carU.Top < 30)
            {
                if (pictureAGVplatform.Left > p.X)
                {
                    pictureAGVplatform.Left -= movement;
                    pictureArm1.Left -= movement;
                    pictureArm2.Left -= movement;
                    pictureStaffa1.Left -= movement;
                    pictureStaffa2.Left -= movement;
                    carU.Left -= movement;
                }
                else TimerUnloadAGV.Enabled = true;

                if (pictureAGVplatform.Left < p.X)
                {
                    pictureAGVplatform.Left += movement;
                    pictureArm1.Left += movement;
                    pictureArm2.Left += movement;
                    pictureStaffa1.Left += movement;
                    pictureStaffa2.Left += movement;
                    carU.Left += movement;
                }
                else TimerUnloadAGV.Enabled = true;

                if (pictureAGVplatform.Left == p.X)
                {
                    removeSimulation(null);
                    parksLights[x, y].BackColor = Color.Lime;
                    tcClient.WriteAny(hvar_name[15 + (4 * x) + y], false); //aggiorna SensorePeso
                    tcClient.WriteAny(hvar_name[36], true); // aggiorna SensoreMacchinaInAGV
                    MacchinaInExit.AddFirst(CarsExitList.First.Value);
                    ParksToExitList.RemoveFirst();
                    CarsExitList.RemoveFirst();
                    TimerUnloadAGV.Enabled = false;
                }
                else TimerUnloadAGV.Enabled = true;


            }
            else TimerUnloadAGV.Enabled = true;
        }


        // TIMER LOAD AGV

        private void TimerLoadAGV_Tick(object sender, EventArgs e)
        {

            if (pictureAGVplatform == null)
            {
                if (pointPark.X > initAGVX)
                {
                    p = new Point(-140, 30);
                }
                if (pointPark.X < initAGVX)
                {
                    p = new Point(170, 30);
                }

                pictureAGVplatform = new PictureBox
                {
                    Location = p,
                    BackColor = System.Drawing.Color.Blue,
                    Size = new Size(140, 140),
                    SizeMode = PictureBoxSizeMode.Zoom,

                };
                pictureArm1 = new PictureBox
                {
                    Size = new Size(20, 140),
                    BackColor = System.Drawing.Color.Gray,
                    SizeMode = PictureBoxSizeMode.Zoom,
                };
                pictureArm2 = new PictureBox
                {
                    Size = new Size(20, 140),
                    BackColor = System.Drawing.Color.Gray,
                    SizeMode = PictureBoxSizeMode.Zoom,
                };
                pictureStaffa1 = new PictureBox
                {
                    Size = new Size(20, 120),
                    BackColor = System.Drawing.Color.DarkGray,
                    SizeMode = PictureBoxSizeMode.Zoom,
                };
                pictureStaffa2 = new PictureBox
                {
                    Size = new Size(20, 120),
                    BackColor = System.Drawing.Color.DarkGray,
                    SizeMode = PictureBoxSizeMode.Zoom,
                };
                pictureSensor.BackColor = System.Drawing.Color.Lime;
                pictureArm1.Top = pictureAGVplatform.Top - 10;
                pictureArm1.Left = pictureAGVplatform.Left + 20;
                carU.Left = pictureArm1.Left + 5;
                carU.Top = pictureArm1.Top;
                pictureArm2.Top = pictureAGVplatform.Top - 10;
                pictureArm2.Left = pictureAGVplatform.Right - 40;
                pictureStaffa1.Top = pictureAGVplatform.Top + 30;
                pictureStaffa1.Left = pictureAGVplatform.Left + 20;
                pictureStaffa2.Top = pictureAGVplatform.Top + 30;
                pictureStaffa2.Left = pictureAGVplatform.Right - 40;
                this.simulationAGV.Controls.Add(pictureAGVplatform);
                this.simulationAGV.Controls.Add(pictureArm1);
                this.simulationAGV.Controls.Add(pictureArm2);
                this.simulationAGV.Controls.Add(pictureStaffa1);
                this.simulationAGV.Controls.Add(pictureStaffa2);
                this.simulationAGV.Controls.Add(carU);
                carU.BringToFront();
                picturePark.SendToBack();
                pictureAGVplatform.SendToBack();

            }
            if (carU.Left > 37)
            {
                pictureAGVplatform.Left -= movement;
                pictureArm1.Left -= movement;
                pictureArm2.Left -= movement;
                pictureStaffa1.Left -= movement;
                pictureStaffa2.Left -= movement;
                carU.Left -= movement;
                TimerLoadAGV.Enabled = true;
            }
            if (carU.Left < 37)
            {
                pictureAGVplatform.Left += movement;
                pictureArm1.Left += movement;
                pictureArm2.Left += movement;
                pictureStaffa1.Left += movement;
                pictureStaffa2.Left += movement;
                carU.Left += movement;
                TimerLoadAGV.Enabled = true;
            }

            if (carU.Left == 37)
            {
                if (carU.Bottom < pictureSensor.Bottom - 15)
                {
                    carU.Top += movement * 2;
                    pictureArm2.Top += movement * 2;
                    pictureArm1.Top += movement * 2;
                    TimerLoadAGV.Enabled = true;
                }
                else
                {
                    if (pictureArm1.Top > 30)
                    {
                        pictureArm2.Top -= movement * 5;
                        pictureArm1.Top -= movement * 5;
                        TimerLoadAGV.Enabled = true;
                    }
                    if (pictureArm1.Top <= 30)
                    {
                        if (pictureAGVplatform.Left > p.X)
                        {
                            pictureAGVplatform.Left -= movement;
                            pictureArm1.Left -= movement;
                            pictureArm2.Left -= movement;
                            pictureStaffa1.Left -= movement;
                            pictureStaffa2.Left -= movement;
                        }
                        else TimerLoadAGV.Enabled = true;
                        if (pictureAGVplatform.Left < p.X)
                        {
                            pictureAGVplatform.Left += movement;
                            pictureArm1.Left += movement;
                            pictureArm2.Left += movement;
                            pictureStaffa1.Left += movement;
                            pictureStaffa2.Left += movement;
                        }
                        else TimerLoadAGV.Enabled = true;
                        if (pictureAGVplatform.Left == p.X)
                        {
                            removeSimulation(CarsLiftList.First.Value);
                            ParksMap.Add(pointPark, CarsLiftList.First.Value);
                            CarsLiftList.RemoveFirst();
                            parksLights[x, y].BackColor = Color.Red;
                            tcClient.WriteAny(hvar_name[15 + (4 * x) + y], true); // aggiunge la macchina in ParksMap e rimuove la simulazione
                            tcClient.WriteAny(hvar_name[40], true); // aggiorna SensoreAgvReady
                            TimerLoadAGV.Enabled = false;
                        }
                        else TimerLoadAGV.Enabled = true;

                    }
                    else TimerLoadAGV.Enabled = true;
                }
            }
            else TimerLoadAGV.Enabled = true;
        }


        // BUTTON CLICK



        private void AddNewCar_Click(object sender, EventArgs e)
        {
            numeroCasuale = r.Next(0, 5);
            if (textStart.Text == "1")
            {
                car = new PictureBox
                {
                    Location = new Point(this.simulation.Right, INITPOINT.Y),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Size = new Size(100, 65),
                    ImageLocation = arrayImagesl[numeroCasuale],
                };
                this.simulation.Controls.Add(car);
                CarsEntranceList.AddLast(car);
                TimerEntranceToLift.Enabled = true;


            }
        }


        private void Start_Click(object sender, EventArgs e)
        {
            if (textStart.Text == "0" && textStop.Text=="0")
            {

                TimerCausalEntrance.Enabled = true;
                TimerRichiestaScarico.Enabled = true;
                textStart.Text = "1";
                textReset.Text = "0";
                MasterTimer.Enabled = true;
                tcClient.WriteAny(hvar_name[35], false); // aggiorna SensoreReset a false

                if (textComandoSali.Text == "True")
                    timerSali.Enabled = true;
                if (textComandoVaiDx.Text == "True")
                    timerVaiDx.Enabled = true; ;
                if (textComandoVaiSx.Text == "True")
                    timerVaiSx.Enabled = true;
                if (textComandoRiposizionaAgv.Text == "True")
                    TimerRiposizionaAGV.Enabled = true;
                if (textComandoRiposizionaLift.Text == "True")
                    timerRiposizionaLift.Enabled = true;
                if (textComandoCarica.Text == "True")
                    TimerLoadAGV.Enabled = false;
                if (textComandoScarica.Text == "True")
                    TimerLoadAGV.Enabled = true;
                if (textComandoPosizionaMacchina.Text == "True")
                    TimerPosizionaSuLift.Enabled = true;
                if (textComandoPortaViaMacchina.Text == "True")
                    timerPortaViaMacchina.Enabled = true;
            }
        }

        private void textStart_TextChanged(object sender, EventArgs e)
        {
            if (hvar_name != null)
            {
                if (textStart.Text.Equals("1"))
                    tcClient.WriteAny(hvar_name[9], true);
                else
                {
                    tcClient.WriteAny(hvar_name[9], false);
                    
                }
            }
        }


           



        private void Reset_Click(object sender, EventArgs e)
        {
            if (textStop.Text == "1" && textGuasto.Text == "0")
            {
                tcClient.WriteAny(hvar_name[35], true); //aggiorna SensoreReset
                textStop.Text = "0";
                textReset.Text = "1";
               
            }
        }



        // INGRESSO MACCHINE

        private void TimerCausalEntrance_Tick(object sender, EventArgs e)
        {
            AddNewCar_Click(sender, e);
            int numeroCasuale2 = r.Next(5, 20);
            TimerCausalEntrance.Interval = numeroCasuale2 * 1000;
            TimerCausalEntrance.Enabled = true;

        }
        private void TimerEntranceToLift_Tick(object sender, EventArgs e)
        {
            LinkedListNode<PictureBox> thisCar = CarsEntranceList.First;

            while (thisCar != null)
            {
                if (thisCar == CarsEntranceList.First)
                {
                    if (thisCar.Value.Left > GateEntrance.Right)
                    {
                        thisCar.Value.Left -= movement+1
                            ;
                    }
                    else if (GateEntrance.BackColor == System.Drawing.Color.Lime)/* &&(textAutoLift.Text == "1" || textLift.Text == "1") && CarsLiftList.Count == 0)*/
                    {
                        MacchinaInEntrance.AddFirst(thisCar.Value); CarsEntranceList.RemoveFirst();
                    }
                }
                else
                {
                    if (thisCar.Value.Left > thisCar.Previous.Value.Right - 40)
                    {
                        thisCar.Value.Left -= movement;
                    }
                }
                thisCar = thisCar.Next;
            }
            TimerEntranceToLift.Enabled = true;
        }


        // RICHIESTA SCARICO

        private void TimerRichiestaScarico_Tick(object sender, EventArgs e)
        {
            int X = r.Next(0, 3);
            int Y = r.Next(0, 3);
            Point park = arrayPoint[X, Y];
            PictureBox car;
            if (ParksMap.TryGetValue(park, out car))
            {
                CarsExitList.AddLast(car);
                ParksToExitList.AddLast(park);
                ParksMap.Remove(park);

            }
            TimerRichiestaScarico.Enabled = true;
        }

        private void aggiornaScaricoPLC()
        {
            Int16 livello;
            Int16 slot;

            for (Int16 i = 0; i < 4; i++)
                for (Int16 j = 1; j < 5; j++)
                    if (ParksToExitList.First.Value == arrayPoint[i, j - 1])
                    {
                        livello = i;
                        slot = j;
                        tcClient.WriteAny(hvar_name[41], livello);
                        tcClient.WriteAny(hvar_name[42], slot);
                        tcClient.WriteAny(hvar_name[43], true);
                    }
        }


        // GESTIONE ALLARME

        private void textComandoAllarme_TextChanged(object sender, EventArgs e)
        {
            if (textComandoAllarme.Text == "True")
            {
                Console.WriteLine("Necessaria Riparazione Ascensore");
            }
                
        }


        private void aggiornaParksLights()
        {
            Boolean pieno = true;
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    if (parksLights[i, j].BackColor == Color.Lime)
                        pieno = false;
            if (pieno == true && textParkFull.Text == "0")
            {
                textParkFull.Text = "1";
            }
            else
            {
                if (textParkFull.Text == "1")
                    textParkFull.Text = "0";
            }
        }


        private void sendToBack()
        {

            label1.SendToBack();
            label2.SendToBack();
            label3.SendToBack();
            label4.SendToBack();
            label21.SendToBack();
            label22.SendToBack();
            label23.SendToBack();
            label24.SendToBack();
            label6.SendToBack();
        }













        // CHIUDO CLASSI PRINCIPALI
    }
}




