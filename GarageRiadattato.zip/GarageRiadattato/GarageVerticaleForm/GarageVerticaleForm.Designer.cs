﻿namespace GarageVerticaleForm
{
    partial class GarageVerticaleForm
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label24 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TimeWatchDog = new System.Windows.Forms.Label();
            this.textTimeWatchDog = new System.Windows.Forms.TextBox();
            this.textComandoAllarme = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textStart = new System.Windows.Forms.TextBox();
            this.textReset = new System.Windows.Forms.TextBox();
            this.Reset = new System.Windows.Forms.Button();
            this.Start = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textComandoPortaViaMacchina = new System.Windows.Forms.TextBox();
            this.textComandoPosizionaMacchina = new System.Windows.Forms.TextBox();
            this.textComandoRiposizionaLift = new System.Windows.Forms.TextBox();
            this.textComandoRiposizionaAgv = new System.Windows.Forms.TextBox();
            this.textComandoScarica = new System.Windows.Forms.TextBox();
            this.textComandoCarica = new System.Windows.Forms.TextBox();
            this.textComandoVaiSx = new System.Windows.Forms.TextBox();
            this.textComandoVaiDx = new System.Windows.Forms.TextBox();
            this.textComandoSali = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textConnection = new System.Windows.Forms.TextBox();
            this.buttonConnection = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textTimeAct = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textScaricoOff = new System.Windows.Forms.TextBox();
            this.textScaricoOn = new System.Windows.Forms.TextBox();
            this.buttonOff = new System.Windows.Forms.Button();
            this.buttonOn = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textParkFull = new System.Windows.Forms.TextBox();
            this.Park04 = new System.Windows.Forms.PictureBox();
            this.Park03 = new System.Windows.Forms.PictureBox();
            this.Park02 = new System.Windows.Forms.PictureBox();
            this.Park01 = new System.Windows.Forms.PictureBox();
            this.Park14 = new System.Windows.Forms.PictureBox();
            this.Park13 = new System.Windows.Forms.PictureBox();
            this.Park12 = new System.Windows.Forms.PictureBox();
            this.Park11 = new System.Windows.Forms.PictureBox();
            this.Park23 = new System.Windows.Forms.PictureBox();
            this.Park24 = new System.Windows.Forms.PictureBox();
            this.Park22 = new System.Windows.Forms.PictureBox();
            this.Park21 = new System.Windows.Forms.PictureBox();
            this.Park34 = new System.Windows.Forms.PictureBox();
            this.Park33 = new System.Windows.Forms.PictureBox();
            this.Park32 = new System.Windows.Forms.PictureBox();
            this.Park31 = new System.Windows.Forms.PictureBox();
            this.buttonRipara = new System.Windows.Forms.Button();
            this.textStop = new System.Windows.Forms.TextBox();
            this.textGuasto = new System.Windows.Forms.TextBox();
            this.buttonGuastoAscensore = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.textDeviScaricare = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.AddCar = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.simulation = new System.Windows.Forms.Panel();
            this.labelPositions = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.picture0B = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.picture2D = new System.Windows.Forms.PictureBox();
            this.picture2C = new System.Windows.Forms.PictureBox();
            this.picture2B = new System.Windows.Forms.PictureBox();
            this.picture1D = new System.Windows.Forms.PictureBox();
            this.picture1C = new System.Windows.Forms.PictureBox();
            this.picture1B = new System.Windows.Forms.PictureBox();
            this.picture3D = new System.Windows.Forms.PictureBox();
            this.picture3C = new System.Windows.Forms.PictureBox();
            this.picture3B = new System.Windows.Forms.PictureBox();
            this.picture3A = new System.Windows.Forms.PictureBox();
            this.picture2A = new System.Windows.Forms.PictureBox();
            this.pictureLift = new System.Windows.Forms.PictureBox();
            this.picture1A = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox0A = new System.Windows.Forms.PictureBox();
            this.pictureBox0D = new System.Windows.Forms.PictureBox();
            this.pictureBox0C = new System.Windows.Forms.PictureBox();
            this.pictureBox0B = new System.Windows.Forms.PictureBox();
            this.pictureBox1C = new System.Windows.Forms.PictureBox();
            this.pictureBox1B = new System.Windows.Forms.PictureBox();
            this.pictureBox1A = new System.Windows.Forms.PictureBox();
            this.pictureBox1D = new System.Windows.Forms.PictureBox();
            this.pictureBox2D = new System.Windows.Forms.PictureBox();
            this.pictureBox2C = new System.Windows.Forms.PictureBox();
            this.pictureBox2B = new System.Windows.Forms.PictureBox();
            this.pictureBox2A = new System.Windows.Forms.PictureBox();
            this.pictureBox3D = new System.Windows.Forms.PictureBox();
            this.pictureBox3C = new System.Windows.Forms.PictureBox();
            this.pictureBox3B = new System.Windows.Forms.PictureBox();
            this.pictureBox3A = new System.Windows.Forms.PictureBox();
            this.pictureAgv = new System.Windows.Forms.PictureBox();
            this.GateExit = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.GateEntrance = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.MasterTimer = new System.Windows.Forms.Timer(this.components);
            this.TimerDelay = new System.Windows.Forms.Timer(this.components);
            this.WatchDog = new System.Windows.Forms.Timer(this.components);
            this.TimerAutoLift = new System.Windows.Forms.Timer(this.components);
            this.TimerAutoUnload = new System.Windows.Forms.Timer(this.components);
            this.TimerCausalEntrance = new System.Windows.Forms.Timer(this.components);
            this.TimerEntranceToLift = new System.Windows.Forms.Timer(this.components);
            this.panel4 = new System.Windows.Forms.Panel();
            this.textSensoreSlot4 = new System.Windows.Forms.TextBox();
            this.textSensoreSlot3 = new System.Windows.Forms.TextBox();
            this.textSensoreSlot2 = new System.Windows.Forms.TextBox();
            this.textSensoreSlot1 = new System.Windows.Forms.TextBox();
            this.textSensoreLivello3 = new System.Windows.Forms.TextBox();
            this.textSensoreLivello2 = new System.Windows.Forms.TextBox();
            this.textSensoreLivello1 = new System.Windows.Forms.TextBox();
            this.textSensoreLivello0 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.textAgvInPos = new System.Windows.Forms.TextBox();
            this.textLiftInPos = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textMacchinaInAGV = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textMacchinaInEntrance = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.picturePark = new System.Windows.Forms.PictureBox();
            this.simulationAGV = new System.Windows.Forms.Panel();
            this.pictureSensor = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TimerLoadAGV = new System.Windows.Forms.Timer(this.components);
            this.TimerUnloadAGV = new System.Windows.Forms.Timer(this.components);
            this.TimerPosizionaSuLift = new System.Windows.Forms.Timer(this.components);
            this.TimerRiposizionaAGV = new System.Windows.Forms.Timer(this.components);
            this.timerSali = new System.Windows.Forms.Timer(this.components);
            this.TimerRichiestaScarico = new System.Windows.Forms.Timer(this.components);
            this.timerSensoriLivelli = new System.Windows.Forms.Timer(this.components);
            this.timerSensoriSlot = new System.Windows.Forms.Timer(this.components);
            this.timerRiposizionaLift = new System.Windows.Forms.Timer(this.components);
            this.timerVaiDx = new System.Windows.Forms.Timer(this.components);
            this.timerVaiSx = new System.Windows.Forms.Timer(this.components);
            this.timerPortaViaMacchina = new System.Windows.Forms.Timer(this.components);
            this.timerDelayLevel = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Park04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park31)).BeginInit();
            this.simulation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture0B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture2D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture2C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture2B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture1D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture1C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture1B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture3D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture3C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture3B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture3A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture2A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLift)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture1A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureAgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GateExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GateEntrance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picturePark)).BeginInit();
            this.simulationAGV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureSensor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            this.SuspendLayout();
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.CausesValidation = false;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label24.Location = new System.Drawing.Point(295, 68);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 63);
            this.label24.TabIndex = 33;
            this.label24.Text = "3";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.TimeWatchDog);
            this.panel1.Controls.Add(this.textTimeWatchDog);
            this.panel1.Controls.Add(this.textComandoAllarme);
            this.panel1.Controls.Add(this.label50);
            this.panel1.Location = new System.Drawing.Point(834, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(163, 59);
            this.panel1.TabIndex = 0;
            // 
            // TimeWatchDog
            // 
            this.TimeWatchDog.AutoSize = true;
            this.TimeWatchDog.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TimeWatchDog.Location = new System.Drawing.Point(15, 32);
            this.TimeWatchDog.Name = "TimeWatchDog";
            this.TimeWatchDog.Size = new System.Drawing.Size(82, 13);
            this.TimeWatchDog.TabIndex = 6;
            this.TimeWatchDog.Text = "TimeWatchDog";
            // 
            // textTimeWatchDog
            // 
            this.textTimeWatchDog.Location = new System.Drawing.Point(111, 29);
            this.textTimeWatchDog.Name = "textTimeWatchDog";
            this.textTimeWatchDog.Size = new System.Drawing.Size(40, 20);
            this.textTimeWatchDog.TabIndex = 5;
            // 
            // textComandoAllarme
            // 
            this.textComandoAllarme.Location = new System.Drawing.Point(111, 4);
            this.textComandoAllarme.Name = "textComandoAllarme";
            this.textComandoAllarme.Size = new System.Drawing.Size(40, 20);
            this.textComandoAllarme.TabIndex = 54;
            this.textComandoAllarme.TextChanged += new System.EventHandler(this.textComandoAllarme_TextChanged);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label50.Location = new System.Drawing.Point(14, 7);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(86, 13);
            this.label50.TabIndex = 53;
            this.label50.Text = "ComandoAllarme";
            // 
            // textStart
            // 
            this.textStart.Location = new System.Drawing.Point(136, 97);
            this.textStart.Name = "textStart";
            this.textStart.Size = new System.Drawing.Size(20, 20);
            this.textStart.TabIndex = 2;
            this.textStart.TextChanged += new System.EventHandler(this.textStart_TextChanged);
            // 
            // textReset
            // 
            this.textReset.Location = new System.Drawing.Point(136, 66);
            this.textReset.Name = "textReset";
            this.textReset.Size = new System.Drawing.Size(20, 20);
            this.textReset.TabIndex = 4;
            // 
            // Reset
            // 
            this.Reset.Location = new System.Drawing.Point(85, 67);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(50, 20);
            this.Reset.TabIndex = 4;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = true;
            this.Reset.Click += new System.EventHandler(this.Reset_Click);
            // 
            // Start
            // 
            this.Start.Location = new System.Drawing.Point(85, 98);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(50, 20);
            this.Start.TabIndex = 2;
            this.Start.Text = "Start";
            this.Start.UseVisualStyleBackColor = true;
            this.Start.Click += new System.EventHandler(this.Start_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.textComandoPortaViaMacchina);
            this.panel2.Controls.Add(this.textComandoPosizionaMacchina);
            this.panel2.Controls.Add(this.textComandoRiposizionaLift);
            this.panel2.Controls.Add(this.textComandoRiposizionaAgv);
            this.panel2.Controls.Add(this.textComandoScarica);
            this.panel2.Controls.Add(this.textComandoCarica);
            this.panel2.Controls.Add(this.textComandoVaiSx);
            this.panel2.Controls.Add(this.textComandoVaiDx);
            this.panel2.Controls.Add(this.textComandoSali);
            this.panel2.Controls.Add(this.label36);
            this.panel2.Controls.Add(this.label35);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.textConnection);
            this.panel2.Controls.Add(this.buttonConnection);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Location = new System.Drawing.Point(834, 77);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(163, 305);
            this.panel2.TabIndex = 1;
            // 
            // textComandoPortaViaMacchina
            // 
            this.textComandoPortaViaMacchina.Location = new System.Drawing.Point(111, 213);
            this.textComandoPortaViaMacchina.Name = "textComandoPortaViaMacchina";
            this.textComandoPortaViaMacchina.Size = new System.Drawing.Size(40, 20);
            this.textComandoPortaViaMacchina.TabIndex = 22;
            this.textComandoPortaViaMacchina.TextChanged += new System.EventHandler(this.textComandoPortaViaMacchina_TextChanged);
            // 
            // textComandoPosizionaMacchina
            // 
            this.textComandoPosizionaMacchina.Location = new System.Drawing.Point(111, 186);
            this.textComandoPosizionaMacchina.Name = "textComandoPosizionaMacchina";
            this.textComandoPosizionaMacchina.Size = new System.Drawing.Size(40, 20);
            this.textComandoPosizionaMacchina.TabIndex = 21;
            this.textComandoPosizionaMacchina.TextChanged += new System.EventHandler(this.textComandoPosizionaMacchina_TextChanged);
            // 
            // textComandoRiposizionaLift
            // 
            this.textComandoRiposizionaLift.Location = new System.Drawing.Point(111, 159);
            this.textComandoRiposizionaLift.Name = "textComandoRiposizionaLift";
            this.textComandoRiposizionaLift.Size = new System.Drawing.Size(40, 20);
            this.textComandoRiposizionaLift.TabIndex = 20;
            this.textComandoRiposizionaLift.TextChanged += new System.EventHandler(this.textComandoRiposizionaLift_TextChanged);
            // 
            // textComandoRiposizionaAgv
            // 
            this.textComandoRiposizionaAgv.Location = new System.Drawing.Point(111, 133);
            this.textComandoRiposizionaAgv.Name = "textComandoRiposizionaAgv";
            this.textComandoRiposizionaAgv.Size = new System.Drawing.Size(40, 20);
            this.textComandoRiposizionaAgv.TabIndex = 19;
            this.textComandoRiposizionaAgv.TextChanged += new System.EventHandler(this.textComandoRiposizionaAgv_TextChanged);
            // 
            // textComandoScarica
            // 
            this.textComandoScarica.Location = new System.Drawing.Point(111, 107);
            this.textComandoScarica.Name = "textComandoScarica";
            this.textComandoScarica.Size = new System.Drawing.Size(40, 20);
            this.textComandoScarica.TabIndex = 18;
            this.textComandoScarica.TextChanged += new System.EventHandler(this.textComandoScarica_TextChanged);
            // 
            // textComandoCarica
            // 
            this.textComandoCarica.Location = new System.Drawing.Point(111, 81);
            this.textComandoCarica.Name = "textComandoCarica";
            this.textComandoCarica.Size = new System.Drawing.Size(40, 20);
            this.textComandoCarica.TabIndex = 17;
            this.textComandoCarica.TextChanged += new System.EventHandler(this.textComandoCarica_TextChanged);
            // 
            // textComandoVaiSx
            // 
            this.textComandoVaiSx.Location = new System.Drawing.Point(111, 55);
            this.textComandoVaiSx.Name = "textComandoVaiSx";
            this.textComandoVaiSx.Size = new System.Drawing.Size(40, 20);
            this.textComandoVaiSx.TabIndex = 16;
            this.textComandoVaiSx.TextChanged += new System.EventHandler(this.textComandoVaiSx_TextChanged);
            // 
            // textComandoVaiDx
            // 
            this.textComandoVaiDx.Location = new System.Drawing.Point(111, 30);
            this.textComandoVaiDx.Name = "textComandoVaiDx";
            this.textComandoVaiDx.Size = new System.Drawing.Size(40, 20);
            this.textComandoVaiDx.TabIndex = 15;
            this.textComandoVaiDx.TextChanged += new System.EventHandler(this.textComandoVaiDx_TextChanged);
            // 
            // textComandoSali
            // 
            this.textComandoSali.Location = new System.Drawing.Point(111, 0);
            this.textComandoSali.Name = "textComandoSali";
            this.textComandoSali.Size = new System.Drawing.Size(40, 20);
            this.textComandoSali.TabIndex = 14;
            this.textComandoSali.TextChanged += new System.EventHandler(this.textComandoSali_TextChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label36.Location = new System.Drawing.Point(3, 216);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(94, 13);
            this.label36.TabIndex = 13;
            this.label36.Text = "PortaViaMacchina";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label35.Location = new System.Drawing.Point(3, 189);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(97, 13);
            this.label35.TabIndex = 12;
            this.label35.Text = "ComandoPosiziona";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label34.Location = new System.Drawing.Point(3, 166);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(75, 13);
            this.label34.TabIndex = 11;
            this.label34.Text = "RiposizionaLift";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label33.Location = new System.Drawing.Point(3, 137);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(80, 13);
            this.label33.TabIndex = 10;
            this.label33.Text = "RiposizionaAgv\r\n";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label32.Location = new System.Drawing.Point(5, 114);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(88, 13);
            this.label32.TabIndex = 9;
            this.label32.Text = "ComandoScarica";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label31.Location = new System.Drawing.Point(8, 83);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(82, 13);
            this.label31.TabIndex = 8;
            this.label31.Text = "ComandoCarica";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label30.Location = new System.Drawing.Point(5, 59);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(79, 13);
            this.label30.TabIndex = 7;
            this.label30.Text = "ComandoVaiSx";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label29.Location = new System.Drawing.Point(5, 33);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(80, 13);
            this.label29.TabIndex = 6;
            this.label29.Text = "ComandoVaiDx";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(5, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "ComandoSali";
            // 
            // textConnection
            // 
            this.textConnection.Location = new System.Drawing.Point(11, 271);
            this.textConnection.Name = "textConnection";
            this.textConnection.Size = new System.Drawing.Size(130, 20);
            this.textConnection.TabIndex = 4;
            // 
            // buttonConnection
            // 
            this.buttonConnection.Location = new System.Drawing.Point(41, 242);
            this.buttonConnection.Name = "buttonConnection";
            this.buttonConnection.Size = new System.Drawing.Size(75, 23);
            this.buttonConnection.TabIndex = 3;
            this.buttonConnection.Text = "Connect";
            this.buttonConnection.UseVisualStyleBackColor = true;
            this.buttonConnection.Click += new System.EventHandler(this.buttonConnection_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "Alarms Process:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.textTimeAct);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.textScaricoOff);
            this.panel3.Controls.Add(this.textScaricoOn);
            this.panel3.Controls.Add(this.buttonOff);
            this.panel3.Controls.Add(this.buttonOn);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.textParkFull);
            this.panel3.Controls.Add(this.Park04);
            this.panel3.Controls.Add(this.Park03);
            this.panel3.Controls.Add(this.Park02);
            this.panel3.Controls.Add(this.Park01);
            this.panel3.Controls.Add(this.Park14);
            this.panel3.Controls.Add(this.Park13);
            this.panel3.Controls.Add(this.Park12);
            this.panel3.Controls.Add(this.Park11);
            this.panel3.Controls.Add(this.Park23);
            this.panel3.Controls.Add(this.Park24);
            this.panel3.Controls.Add(this.Park22);
            this.panel3.Controls.Add(this.Park21);
            this.panel3.Controls.Add(this.Park34);
            this.panel3.Controls.Add(this.Park33);
            this.panel3.Controls.Add(this.Park32);
            this.panel3.Controls.Add(this.Park31);
            this.panel3.Controls.Add(this.buttonRipara);
            this.panel3.Controls.Add(this.textStop);
            this.panel3.Controls.Add(this.textReset);
            this.panel3.Controls.Add(this.textStart);
            this.panel3.Controls.Add(this.Reset);
            this.panel3.Controls.Add(this.textGuasto);
            this.panel3.Controls.Add(this.buttonGuastoAscensore);
            this.panel3.Controls.Add(this.buttonStop);
            this.panel3.Controls.Add(this.Start);
            this.panel3.Controls.Add(this.textDeviScaricare);
            this.panel3.Controls.Add(this.label49);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.AddCar);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Location = new System.Drawing.Point(665, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(163, 370);
            this.panel3.TabIndex = 1;
            // 
            // textTimeAct
            // 
            this.textTimeAct.Location = new System.Drawing.Point(95, 33);
            this.textTimeAct.Name = "textTimeAct";
            this.textTimeAct.Size = new System.Drawing.Size(40, 20);
            this.textTimeAct.TabIndex = 88;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(32, 39);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 13);
            this.label20.TabIndex = 87;
            this.label20.Text = "Time Act";
            // 
            // textScaricoOff
            // 
            this.textScaricoOff.Location = new System.Drawing.Point(136, 339);
            this.textScaricoOff.Name = "textScaricoOff";
            this.textScaricoOff.Size = new System.Drawing.Size(19, 20);
            this.textScaricoOff.TabIndex = 86;
            // 
            // textScaricoOn
            // 
            this.textScaricoOn.Location = new System.Drawing.Point(136, 298);
            this.textScaricoOn.Name = "textScaricoOn";
            this.textScaricoOn.Size = new System.Drawing.Size(20, 20);
            this.textScaricoOn.TabIndex = 85;
            
            // 
            // buttonOff
            // 
            this.buttonOff.Location = new System.Drawing.Point(72, 336);
            this.buttonOff.Name = "buttonOff";
            this.buttonOff.Size = new System.Drawing.Size(50, 23);
            this.buttonOff.TabIndex = 84;
            this.buttonOff.Text = "OFF";
            this.buttonOff.UseVisualStyleBackColor = true;
            this.buttonOff.Click += new System.EventHandler(this.buttonOff_Click);
            // 
            // buttonOn
            // 
            this.buttonOn.Location = new System.Drawing.Point(72, 295);
            this.buttonOn.Name = "buttonOn";
            this.buttonOn.Size = new System.Drawing.Size(50, 23);
            this.buttonOn.TabIndex = 83;
            this.buttonOn.Text = "ON";
            this.buttonOn.UseVisualStyleBackColor = true;
            this.buttonOn.Click += new System.EventHandler(this.buttonOn_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(13, 321);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 13);
            this.label14.TabIndex = 82;
            this.label14.Text = "Scarico";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(30, 270);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 13);
            this.label11.TabIndex = 81;
            this.label11.Text = "Park Full";
            // 
            // textParkFull
            // 
            this.textParkFull.Location = new System.Drawing.Point(95, 263);
            this.textParkFull.Name = "textParkFull";
            this.textParkFull.Size = new System.Drawing.Size(20, 20);
            this.textParkFull.TabIndex = 80;
            this.textParkFull.TextChanged += new System.EventHandler(this.textParkFull_TextChanged);
            // 
            // Park04
            // 
            this.Park04.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park04.Location = new System.Drawing.Point(107, 204);
            this.Park04.Name = "Park04";
            this.Park04.Size = new System.Drawing.Size(20, 20);
            this.Park04.TabIndex = 79;
            this.Park04.TabStop = false;
            // 
            // Park03
            // 
            this.Park03.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park03.Location = new System.Drawing.Point(80, 204);
            this.Park03.Name = "Park03";
            this.Park03.Size = new System.Drawing.Size(20, 20);
            this.Park03.TabIndex = 78;
            this.Park03.TabStop = false;
            // 
            // Park02
            // 
            this.Park02.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park02.Location = new System.Drawing.Point(54, 204);
            this.Park02.Name = "Park02";
            this.Park02.Size = new System.Drawing.Size(20, 20);
            this.Park02.TabIndex = 77;
            this.Park02.TabStop = false;
            // 
            // Park01
            // 
            this.Park01.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park01.Location = new System.Drawing.Point(28, 204);
            this.Park01.Name = "Park01";
            this.Park01.Size = new System.Drawing.Size(20, 20);
            this.Park01.TabIndex = 76;
            this.Park01.TabStop = false;
            // 
            // Park14
            // 
            this.Park14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park14.Location = new System.Drawing.Point(107, 179);
            this.Park14.Name = "Park14";
            this.Park14.Size = new System.Drawing.Size(20, 20);
            this.Park14.TabIndex = 75;
            this.Park14.TabStop = false;
            // 
            // Park13
            // 
            this.Park13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park13.Location = new System.Drawing.Point(80, 179);
            this.Park13.Name = "Park13";
            this.Park13.Size = new System.Drawing.Size(20, 20);
            this.Park13.TabIndex = 74;
            this.Park13.TabStop = false;
            // 
            // Park12
            // 
            this.Park12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park12.Location = new System.Drawing.Point(54, 179);
            this.Park12.Name = "Park12";
            this.Park12.Size = new System.Drawing.Size(20, 20);
            this.Park12.TabIndex = 73;
            this.Park12.TabStop = false;
            // 
            // Park11
            // 
            this.Park11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park11.Location = new System.Drawing.Point(28, 179);
            this.Park11.Name = "Park11";
            this.Park11.Size = new System.Drawing.Size(20, 20);
            this.Park11.TabIndex = 72;
            this.Park11.TabStop = false;
            // 
            // Park23
            // 
            this.Park23.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park23.Location = new System.Drawing.Point(81, 153);
            this.Park23.Name = "Park23";
            this.Park23.Size = new System.Drawing.Size(20, 20);
            this.Park23.TabIndex = 71;
            this.Park23.TabStop = false;
            // 
            // Park24
            // 
            this.Park24.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park24.Location = new System.Drawing.Point(107, 153);
            this.Park24.Name = "Park24";
            this.Park24.Size = new System.Drawing.Size(20, 20);
            this.Park24.TabIndex = 70;
            this.Park24.TabStop = false;
            // 
            // Park22
            // 
            this.Park22.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park22.Location = new System.Drawing.Point(54, 153);
            this.Park22.Name = "Park22";
            this.Park22.Size = new System.Drawing.Size(20, 20);
            this.Park22.TabIndex = 69;
            this.Park22.TabStop = false;
            // 
            // Park21
            // 
            this.Park21.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park21.Location = new System.Drawing.Point(28, 152);
            this.Park21.Name = "Park21";
            this.Park21.Size = new System.Drawing.Size(20, 20);
            this.Park21.TabIndex = 68;
            this.Park21.TabStop = false;
            // 
            // Park34
            // 
            this.Park34.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park34.Location = new System.Drawing.Point(107, 127);
            this.Park34.Name = "Park34";
            this.Park34.Size = new System.Drawing.Size(20, 20);
            this.Park34.TabIndex = 67;
            this.Park34.TabStop = false;
            // 
            // Park33
            // 
            this.Park33.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park33.Location = new System.Drawing.Point(80, 127);
            this.Park33.Name = "Park33";
            this.Park33.Size = new System.Drawing.Size(20, 20);
            this.Park33.TabIndex = 66;
            this.Park33.TabStop = false;
            // 
            // Park32
            // 
            this.Park32.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park32.Location = new System.Drawing.Point(54, 127);
            this.Park32.Name = "Park32";
            this.Park32.Size = new System.Drawing.Size(20, 20);
            this.Park32.TabIndex = 65;
            this.Park32.TabStop = false;
            // 
            // Park31
            // 
            this.Park31.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Park31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Park31.Location = new System.Drawing.Point(28, 126);
            this.Park31.Name = "Park31";
            this.Park31.Size = new System.Drawing.Size(20, 20);
            this.Park31.TabIndex = 64;
            this.Park31.TabStop = false;
            // 
            // buttonRipara
            // 
            this.buttonRipara.Location = new System.Drawing.Point(95, 4);
            this.buttonRipara.Name = "buttonRipara";
            this.buttonRipara.Size = new System.Drawing.Size(55, 23);
            this.buttonRipara.TabIndex = 63;
            this.buttonRipara.Text = "Ripara";
            this.buttonRipara.UseVisualStyleBackColor = true;
            this.buttonRipara.Click += new System.EventHandler(this.buttonRipara_Click);
            // 
            // textStop
            // 
            this.textStop.Location = new System.Drawing.Point(59, 98);
            this.textStop.Name = "textStop";
            this.textStop.Size = new System.Drawing.Size(20, 20);
            this.textStop.TabIndex = 62;
            // 
            // textGuasto
            // 
            this.textGuasto.Location = new System.Drawing.Point(59, 68);
            this.textGuasto.Name = "textGuasto";
            this.textGuasto.Size = new System.Drawing.Size(20, 20);
            this.textGuasto.TabIndex = 61;
            this.textGuasto.TextChanged += new System.EventHandler(this.textGuasto_TextChanged);
            // 
            // buttonGuastoAscensore
            // 
            this.buttonGuastoAscensore.Cursor = System.Windows.Forms.Cursors.Default;
            this.buttonGuastoAscensore.Location = new System.Drawing.Point(6, 66);
            this.buttonGuastoAscensore.Name = "buttonGuastoAscensore";
            this.buttonGuastoAscensore.Size = new System.Drawing.Size(50, 23);
            this.buttonGuastoAscensore.TabIndex = 60;
            this.buttonGuastoAscensore.Text = "Guasto Ascensore";
            this.buttonGuastoAscensore.UseVisualStyleBackColor = true;
            this.buttonGuastoAscensore.Click += new System.EventHandler(this.buttonGuastoAscensore_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(6, 95);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(50, 23);
            this.buttonStop.TabIndex = 59;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // textDeviScaricare
            // 
            this.textDeviScaricare.Location = new System.Drawing.Point(95, 238);
            this.textDeviScaricare.Name = "textDeviScaricare";
            this.textDeviScaricare.Size = new System.Drawing.Size(40, 20);
            this.textDeviScaricare.TabIndex = 52;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label49.Location = new System.Drawing.Point(5, 241);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(74, 13);
            this.label49.TabIndex = 51;
            this.label49.Text = "DeviScaricare";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 284);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 43;
            this.label5.Text = "Automatic Comands:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 205);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 179);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(13, 13);
            this.label12.TabIndex = 27;
            this.label12.Text = "1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 153);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(13, 13);
            this.label13.TabIndex = 23;
            this.label13.Text = "2";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 127);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 21;
            this.label15.Text = "3";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(64, 198);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 13);
            this.label16.TabIndex = 22;
            this.label16.Text = "B";
            // 
            // AddCar
            // 
            this.AddCar.Location = new System.Drawing.Point(6, 4);
            this.AddCar.Name = "AddCar";
            this.AddCar.Size = new System.Drawing.Size(75, 20);
            this.AddCar.TabIndex = 23;
            this.AddCar.Text = "AddCar";
            this.AddCar.UseVisualStyleBackColor = true;
            this.AddCar.Click += new System.EventHandler(this.AddNewCar_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(44, 198);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 13);
            this.label17.TabIndex = 19;
            this.label17.Text = "A";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 98);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(92, 13);
            this.label18.TabIndex = 19;
            this.label18.Text = "Manual Comands:";
            // 
            // simulation
            // 
            this.simulation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.simulation.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.simulation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.simulation.Controls.Add(this.labelPositions);
            this.simulation.Controls.Add(this.label6);
            this.simulation.Controls.Add(this.pictureBox11);
            this.simulation.Controls.Add(this.pictureBox3);
            this.simulation.Controls.Add(this.pictureBox1);
            this.simulation.Controls.Add(this.label28);
            this.simulation.Controls.Add(this.label27);
            this.simulation.Controls.Add(this.label26);
            this.simulation.Controls.Add(this.label25);
            this.simulation.Controls.Add(this.pictureBox2);
            this.simulation.Controls.Add(this.picture0B);
            this.simulation.Controls.Add(this.pictureBox7);
            this.simulation.Controls.Add(this.pictureBox10);
            this.simulation.Controls.Add(this.pictureBox4);
            this.simulation.Controls.Add(this.pictureBox9);
            this.simulation.Controls.Add(this.pictureBox8);
            this.simulation.Controls.Add(this.pictureBox5);
            this.simulation.Controls.Add(this.picture2D);
            this.simulation.Controls.Add(this.picture2C);
            this.simulation.Controls.Add(this.picture2B);
            this.simulation.Controls.Add(this.picture1D);
            this.simulation.Controls.Add(this.picture1C);
            this.simulation.Controls.Add(this.picture1B);
            this.simulation.Controls.Add(this.picture3D);
            this.simulation.Controls.Add(this.picture3C);
            this.simulation.Controls.Add(this.picture3B);
            this.simulation.Controls.Add(this.picture3A);
            this.simulation.Controls.Add(this.picture2A);
            this.simulation.Controls.Add(this.pictureLift);
            this.simulation.Controls.Add(this.picture1A);
            this.simulation.Controls.Add(this.pictureBox6);
            this.simulation.Controls.Add(this.pictureBox0A);
            this.simulation.Controls.Add(this.pictureBox0D);
            this.simulation.Controls.Add(this.pictureBox0C);
            this.simulation.Controls.Add(this.pictureBox0B);
            this.simulation.Controls.Add(this.pictureBox1C);
            this.simulation.Controls.Add(this.pictureBox1B);
            this.simulation.Controls.Add(this.pictureBox1A);
            this.simulation.Controls.Add(this.pictureBox1D);
            this.simulation.Controls.Add(this.pictureBox2D);
            this.simulation.Controls.Add(this.pictureBox2C);
            this.simulation.Controls.Add(this.pictureBox2B);
            this.simulation.Controls.Add(this.pictureBox2A);
            this.simulation.Controls.Add(this.pictureBox3D);
            this.simulation.Controls.Add(this.pictureBox3C);
            this.simulation.Controls.Add(this.pictureBox3B);
            this.simulation.Controls.Add(this.pictureBox3A);
            this.simulation.Controls.Add(this.pictureAgv);
            this.simulation.Controls.Add(this.GateExit);
            this.simulation.Controls.Add(this.pictureBox15);
            this.simulation.Controls.Add(this.pictureBox14);
            this.simulation.Controls.Add(this.GateEntrance);
            this.simulation.Controls.Add(this.pictureBox13);
            this.simulation.Controls.Add(this.pictureBox12);
            this.simulation.Controls.Add(this.label21);
            this.simulation.Controls.Add(this.label22);
            this.simulation.Controls.Add(this.label23);
            this.simulation.Controls.Add(this.label1);
            this.simulation.Controls.Add(this.label2);
            this.simulation.Controls.Add(this.label4);
            this.simulation.Controls.Add(this.label3);
            this.simulation.Controls.Add(this.label24);
            this.simulation.Location = new System.Drawing.Point(12, 12);
            this.simulation.Name = "simulation";
            this.simulation.Size = new System.Drawing.Size(647, 707);
            this.simulation.TabIndex = 4;
            // 
            // labelPositions
            // 
            this.labelPositions.AutoSize = true;
            this.labelPositions.BackColor = System.Drawing.Color.Black;
            this.labelPositions.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelPositions.Location = new System.Drawing.Point(7, 681);
            this.labelPositions.Name = "labelPositions";
            this.labelPositions.Size = new System.Drawing.Size(13, 13);
            this.labelPositions.TabIndex = 56;
            this.labelPositions.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(303, 616);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 17);
            this.label6.TabIndex = 55;
            this.label6.Text = "LIFT";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox11.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox11.Location = new System.Drawing.Point(372, 673);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(270, 30);
            this.pictureBox11.TabIndex = 18;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox3.Location = new System.Drawing.Point(0, 673);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(270, 30);
            this.pictureBox3.TabIndex = 18;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox1.Location = new System.Drawing.Point(0, 604);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(270, 10);
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Red;
            this.label28.CausesValidation = false;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label28.Location = new System.Drawing.Point(562, 2);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 25);
            this.label28.TabIndex = 37;
            this.label28.Text = "D";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Red;
            this.label27.CausesValidation = false;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label27.Location = new System.Drawing.Point(428, 2);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(27, 25);
            this.label27.TabIndex = 36;
            this.label27.Text = "C";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Red;
            this.label26.CausesValidation = false;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label26.Location = new System.Drawing.Point(189, 2);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(25, 25);
            this.label26.TabIndex = 35;
            this.label26.Text = "B";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Red;
            this.label25.CausesValidation = false;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Location = new System.Drawing.Point(58, 2);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 25);
            this.label25.TabIndex = 34;
            this.label25.Text = "A";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox2.BackColor = System.Drawing.Color.Red;
            this.pictureBox2.Location = new System.Drawing.Point(0, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(643, 30);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // picture0B
            // 
            this.picture0B.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture0B.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture0B.Location = new System.Drawing.Point(373, 604);
            this.picture0B.Name = "picture0B";
            this.picture0B.Size = new System.Drawing.Size(270, 10);
            this.picture0B.TabIndex = 17;
            this.picture0B.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox7.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox7.Location = new System.Drawing.Point(260, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(10, 600);
            this.pictureBox7.TabIndex = 7;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox10.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox10.Location = new System.Drawing.Point(130, 4);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(10, 600);
            this.pictureBox10.TabIndex = 11;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox4.Location = new System.Drawing.Point(0, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(10, 600);
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox9.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox9.Location = new System.Drawing.Point(502, 4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(10, 600);
            this.pictureBox9.TabIndex = 10;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox8.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox8.Location = new System.Drawing.Point(373, 4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(10, 600);
            this.pictureBox8.TabIndex = 9;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox5.Location = new System.Drawing.Point(632, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(10, 600);
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // picture2D
            // 
            this.picture2D.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture2D.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture2D.Location = new System.Drawing.Point(512, 304);
            this.picture2D.Name = "picture2D";
            this.picture2D.Size = new System.Drawing.Size(120, 30);
            this.picture2D.TabIndex = 26;
            this.picture2D.TabStop = false;
            // 
            // picture2C
            // 
            this.picture2C.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture2C.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture2C.Location = new System.Drawing.Point(382, 304);
            this.picture2C.Name = "picture2C";
            this.picture2C.Size = new System.Drawing.Size(120, 30);
            this.picture2C.TabIndex = 25;
            this.picture2C.TabStop = false;
            // 
            // picture2B
            // 
            this.picture2B.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture2B.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture2B.Location = new System.Drawing.Point(140, 304);
            this.picture2B.Name = "picture2B";
            this.picture2B.Size = new System.Drawing.Size(120, 30);
            this.picture2B.TabIndex = 24;
            this.picture2B.TabStop = false;
            // 
            // picture1D
            // 
            this.picture1D.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture1D.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture1D.Location = new System.Drawing.Point(512, 454);
            this.picture1D.Name = "picture1D";
            this.picture1D.Size = new System.Drawing.Size(120, 30);
            this.picture1D.TabIndex = 22;
            this.picture1D.TabStop = false;
            // 
            // picture1C
            // 
            this.picture1C.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture1C.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture1C.Location = new System.Drawing.Point(382, 454);
            this.picture1C.Name = "picture1C";
            this.picture1C.Size = new System.Drawing.Size(120, 30);
            this.picture1C.TabIndex = 21;
            this.picture1C.TabStop = false;
            // 
            // picture1B
            // 
            this.picture1B.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture1B.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture1B.Location = new System.Drawing.Point(140, 454);
            this.picture1B.Name = "picture1B";
            this.picture1B.Size = new System.Drawing.Size(120, 30);
            this.picture1B.TabIndex = 20;
            this.picture1B.TabStop = false;
            // 
            // picture3D
            // 
            this.picture3D.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture3D.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture3D.Location = new System.Drawing.Point(512, 154);
            this.picture3D.Name = "picture3D";
            this.picture3D.Size = new System.Drawing.Size(120, 30);
            this.picture3D.TabIndex = 30;
            this.picture3D.TabStop = false;
            // 
            // picture3C
            // 
            this.picture3C.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture3C.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture3C.Location = new System.Drawing.Point(382, 154);
            this.picture3C.Name = "picture3C";
            this.picture3C.Size = new System.Drawing.Size(120, 30);
            this.picture3C.TabIndex = 29;
            this.picture3C.TabStop = false;
            // 
            // picture3B
            // 
            this.picture3B.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture3B.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture3B.Location = new System.Drawing.Point(140, 154);
            this.picture3B.Name = "picture3B";
            this.picture3B.Size = new System.Drawing.Size(120, 30);
            this.picture3B.TabIndex = 28;
            this.picture3B.TabStop = false;
            // 
            // picture3A
            // 
            this.picture3A.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture3A.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture3A.Location = new System.Drawing.Point(10, 154);
            this.picture3A.Name = "picture3A";
            this.picture3A.Size = new System.Drawing.Size(120, 30);
            this.picture3A.TabIndex = 27;
            this.picture3A.TabStop = false;
            // 
            // picture2A
            // 
            this.picture2A.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture2A.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture2A.Location = new System.Drawing.Point(10, 304);
            this.picture2A.Name = "picture2A";
            this.picture2A.Size = new System.Drawing.Size(120, 30);
            this.picture2A.TabIndex = 23;
            this.picture2A.TabStop = false;
            // 
            // pictureLift
            // 
            this.pictureLift.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureLift.BackColor = System.Drawing.Color.Red;
            this.pictureLift.Location = new System.Drawing.Point(277, 684);
            this.pictureLift.Name = "pictureLift";
            this.pictureLift.Size = new System.Drawing.Size(90, 10);
            this.pictureLift.TabIndex = 5;
            this.pictureLift.TabStop = false;
            // 
            // picture1A
            // 
            this.picture1A.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picture1A.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picture1A.Location = new System.Drawing.Point(10, 454);
            this.picture1A.Name = "picture1A";
            this.picture1A.Size = new System.Drawing.Size(120, 30);
            this.picture1A.TabIndex = 13;
            this.picture1A.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox6.Location = new System.Drawing.Point(324, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(0, 0);
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox0A
            // 
            this.pictureBox0A.BackColor = System.Drawing.Color.Black;
            this.pictureBox0A.Location = new System.Drawing.Point(65, 597);
            this.pictureBox0A.Name = "pictureBox0A";
            this.pictureBox0A.Size = new System.Drawing.Size(10, 10);
            this.pictureBox0A.TabIndex = 6;
            this.pictureBox0A.TabStop = false;
            // 
            // pictureBox0D
            // 
            this.pictureBox0D.BackColor = System.Drawing.Color.Black;
            this.pictureBox0D.Location = new System.Drawing.Point(568, 597);
            this.pictureBox0D.Name = "pictureBox0D";
            this.pictureBox0D.Size = new System.Drawing.Size(10, 10);
            this.pictureBox0D.TabIndex = 7;
            this.pictureBox0D.TabStop = false;
            // 
            // pictureBox0C
            // 
            this.pictureBox0C.BackColor = System.Drawing.Color.Black;
            this.pictureBox0C.Location = new System.Drawing.Point(437, 597);
            this.pictureBox0C.Name = "pictureBox0C";
            this.pictureBox0C.Size = new System.Drawing.Size(10, 10);
            this.pictureBox0C.TabIndex = 7;
            this.pictureBox0C.TabStop = false;
            // 
            // pictureBox0B
            // 
            this.pictureBox0B.BackColor = System.Drawing.Color.Black;
            this.pictureBox0B.Location = new System.Drawing.Point(194, 597);
            this.pictureBox0B.Name = "pictureBox0B";
            this.pictureBox0B.Size = new System.Drawing.Size(10, 10);
            this.pictureBox0B.TabIndex = 38;
            this.pictureBox0B.TabStop = false;
            // 
            // pictureBox1C
            // 
            this.pictureBox1C.BackColor = System.Drawing.Color.Black;
            this.pictureBox1C.Location = new System.Drawing.Point(437, 447);
            this.pictureBox1C.Name = "pictureBox1C";
            this.pictureBox1C.Size = new System.Drawing.Size(10, 10);
            this.pictureBox1C.TabIndex = 40;
            this.pictureBox1C.TabStop = false;
            // 
            // pictureBox1B
            // 
            this.pictureBox1B.BackColor = System.Drawing.Color.Black;
            this.pictureBox1B.Location = new System.Drawing.Point(194, 447);
            this.pictureBox1B.Name = "pictureBox1B";
            this.pictureBox1B.Size = new System.Drawing.Size(10, 10);
            this.pictureBox1B.TabIndex = 39;
            this.pictureBox1B.TabStop = false;
            // 
            // pictureBox1A
            // 
            this.pictureBox1A.BackColor = System.Drawing.Color.Black;
            this.pictureBox1A.Location = new System.Drawing.Point(65, 447);
            this.pictureBox1A.Name = "pictureBox1A";
            this.pictureBox1A.Size = new System.Drawing.Size(10, 10);
            this.pictureBox1A.TabIndex = 7;
            this.pictureBox1A.TabStop = false;
            // 
            // pictureBox1D
            // 
            this.pictureBox1D.BackColor = System.Drawing.Color.Black;
            this.pictureBox1D.Location = new System.Drawing.Point(568, 447);
            this.pictureBox1D.Name = "pictureBox1D";
            this.pictureBox1D.Size = new System.Drawing.Size(10, 10);
            this.pictureBox1D.TabIndex = 41;
            this.pictureBox1D.TabStop = false;
            // 
            // pictureBox2D
            // 
            this.pictureBox2D.BackColor = System.Drawing.Color.Black;
            this.pictureBox2D.Location = new System.Drawing.Point(568, 297);
            this.pictureBox2D.Name = "pictureBox2D";
            this.pictureBox2D.Size = new System.Drawing.Size(10, 10);
            this.pictureBox2D.TabIndex = 45;
            this.pictureBox2D.TabStop = false;
            // 
            // pictureBox2C
            // 
            this.pictureBox2C.BackColor = System.Drawing.Color.Black;
            this.pictureBox2C.Location = new System.Drawing.Point(437, 297);
            this.pictureBox2C.Name = "pictureBox2C";
            this.pictureBox2C.Size = new System.Drawing.Size(10, 10);
            this.pictureBox2C.TabIndex = 44;
            this.pictureBox2C.TabStop = false;
            // 
            // pictureBox2B
            // 
            this.pictureBox2B.BackColor = System.Drawing.Color.Black;
            this.pictureBox2B.Location = new System.Drawing.Point(194, 297);
            this.pictureBox2B.Name = "pictureBox2B";
            this.pictureBox2B.Size = new System.Drawing.Size(10, 10);
            this.pictureBox2B.TabIndex = 43;
            this.pictureBox2B.TabStop = false;
            // 
            // pictureBox2A
            // 
            this.pictureBox2A.BackColor = System.Drawing.Color.Black;
            this.pictureBox2A.Location = new System.Drawing.Point(65, 297);
            this.pictureBox2A.Name = "pictureBox2A";
            this.pictureBox2A.Size = new System.Drawing.Size(10, 10);
            this.pictureBox2A.TabIndex = 42;
            this.pictureBox2A.TabStop = false;
            // 
            // pictureBox3D
            // 
            this.pictureBox3D.BackColor = System.Drawing.Color.Black;
            this.pictureBox3D.Location = new System.Drawing.Point(568, 148);
            this.pictureBox3D.Name = "pictureBox3D";
            this.pictureBox3D.Size = new System.Drawing.Size(10, 10);
            this.pictureBox3D.TabIndex = 48;
            this.pictureBox3D.TabStop = false;
            // 
            // pictureBox3C
            // 
            this.pictureBox3C.BackColor = System.Drawing.Color.Black;
            this.pictureBox3C.Location = new System.Drawing.Point(437, 148);
            this.pictureBox3C.Name = "pictureBox3C";
            this.pictureBox3C.Size = new System.Drawing.Size(10, 10);
            this.pictureBox3C.TabIndex = 47;
            this.pictureBox3C.TabStop = false;
            // 
            // pictureBox3B
            // 
            this.pictureBox3B.BackColor = System.Drawing.Color.Black;
            this.pictureBox3B.Location = new System.Drawing.Point(194, 148);
            this.pictureBox3B.Name = "pictureBox3B";
            this.pictureBox3B.Size = new System.Drawing.Size(10, 10);
            this.pictureBox3B.TabIndex = 7;
            this.pictureBox3B.TabStop = false;
            // 
            // pictureBox3A
            // 
            this.pictureBox3A.BackColor = System.Drawing.Color.Black;
            this.pictureBox3A.Location = new System.Drawing.Point(65, 148);
            this.pictureBox3A.Name = "pictureBox3A";
            this.pictureBox3A.Size = new System.Drawing.Size(10, 10);
            this.pictureBox3A.TabIndex = 46;
            this.pictureBox3A.TabStop = false;
            // 
            // pictureAgv
            // 
            this.pictureAgv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureAgv.BackColor = System.Drawing.Color.Blue;
            this.pictureAgv.Location = new System.Drawing.Point(277, 674);
            this.pictureAgv.Name = "pictureAgv";
            this.pictureAgv.Size = new System.Drawing.Size(90, 10);
            this.pictureAgv.TabIndex = 16;
            this.pictureAgv.TabStop = false;
            // 
            // GateExit
            // 
            this.GateExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.GateExit.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.GateExit.Location = new System.Drawing.Point(260, 614);
            this.GateExit.Name = "GateExit";
            this.GateExit.Size = new System.Drawing.Size(10, 60);
            this.GateExit.TabIndex = 53;
            this.GateExit.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox15.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox15.Location = new System.Drawing.Point(130, 614);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(10, 60);
            this.pictureBox15.TabIndex = 52;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox14.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox14.Location = new System.Drawing.Point(0, 614);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(10, 60);
            this.pictureBox14.TabIndex = 51;
            this.pictureBox14.TabStop = false;
            // 
            // GateEntrance
            // 
            this.GateEntrance.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.GateEntrance.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.GateEntrance.Location = new System.Drawing.Point(373, 614);
            this.GateEntrance.Name = "GateEntrance";
            this.GateEntrance.Size = new System.Drawing.Size(10, 60);
            this.GateEntrance.TabIndex = 54;
            this.GateEntrance.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox13.Location = new System.Drawing.Point(632, 614);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(10, 60);
            this.pictureBox13.TabIndex = 50;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox12.Location = new System.Drawing.Point(502, 614);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(10, 60);
            this.pictureBox12.TabIndex = 19;
            this.pictureBox12.TabStop = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label21.Location = new System.Drawing.Point(295, 519);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(57, 63);
            this.label21.TabIndex = 6;
            this.label21.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label22.Location = new System.Drawing.Point(295, 373);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 63);
            this.label22.TabIndex = 31;
            this.label22.Text = "1";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label23.Location = new System.Drawing.Point(295, 210);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(57, 63);
            this.label23.TabIndex = 32;
            this.label23.Text = "2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(541, 616);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "ENTRANCE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(12, 616);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "EXIT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(12, 633);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "<<";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(594, 633);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "<<";
            // 
            // MasterTimer
            // 
            this.MasterTimer.Interval = 25;
            this.MasterTimer.Tick += new System.EventHandler(this.MasterTimer_Tick);
            // 
            // TimerDelay
            // 
            this.TimerDelay.Tick += new System.EventHandler(this.TimerDelay_Tick);
            // 
            // WatchDog
            // 
            this.WatchDog.Interval = 5000;
            // 
            // TimerCausalEntrance
            // 
            this.TimerCausalEntrance.Interval = 250;
            this.TimerCausalEntrance.Tick += new System.EventHandler(this.TimerCausalEntrance_Tick);
            // 
            // TimerEntranceToLift
            // 
            this.TimerEntranceToLift.Interval = 25;
            this.TimerEntranceToLift.Tick += new System.EventHandler(this.TimerEntranceToLift_Tick);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.textSensoreSlot4);
            this.panel4.Controls.Add(this.textSensoreSlot3);
            this.panel4.Controls.Add(this.textSensoreSlot2);
            this.panel4.Controls.Add(this.textSensoreSlot1);
            this.panel4.Controls.Add(this.textSensoreLivello3);
            this.panel4.Controls.Add(this.textSensoreLivello2);
            this.panel4.Controls.Add(this.textSensoreLivello1);
            this.panel4.Controls.Add(this.textSensoreLivello0);
            this.panel4.Controls.Add(this.label48);
            this.panel4.Controls.Add(this.label47);
            this.panel4.Controls.Add(this.label46);
            this.panel4.Controls.Add(this.label45);
            this.panel4.Controls.Add(this.label44);
            this.panel4.Controls.Add(this.label43);
            this.panel4.Controls.Add(this.label42);
            this.panel4.Controls.Add(this.label40);
            this.panel4.Controls.Add(this.textAgvInPos);
            this.panel4.Controls.Add(this.textLiftInPos);
            this.panel4.Controls.Add(this.label41);
            this.panel4.Controls.Add(this.label39);
            this.panel4.Controls.Add(this.textMacchinaInAGV);
            this.panel4.Controls.Add(this.label38);
            this.panel4.Controls.Add(this.textMacchinaInEntrance);
            this.panel4.Controls.Add(this.label37);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Location = new System.Drawing.Point(834, 387);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(160, 331);
            this.panel4.TabIndex = 5;
            // 
            // textSensoreSlot4
            // 
            this.textSensoreSlot4.Location = new System.Drawing.Point(131, 306);
            this.textSensoreSlot4.Name = "textSensoreSlot4";
            this.textSensoreSlot4.Size = new System.Drawing.Size(20, 20);
            this.textSensoreSlot4.TabIndex = 32;
            this.textSensoreSlot4.TextChanged += new System.EventHandler(this.textSensoreSlot4_TextChanged);
            // 
            // textSensoreSlot3
            // 
            this.textSensoreSlot3.Location = new System.Drawing.Point(131, 279);
            this.textSensoreSlot3.Name = "textSensoreSlot3";
            this.textSensoreSlot3.Size = new System.Drawing.Size(20, 20);
            this.textSensoreSlot3.TabIndex = 31;
            this.textSensoreSlot3.TextChanged += new System.EventHandler(this.textSensoreSlot3_TextChanged);
            // 
            // textSensoreSlot2
            // 
            this.textSensoreSlot2.Location = new System.Drawing.Point(131, 251);
            this.textSensoreSlot2.Name = "textSensoreSlot2";
            this.textSensoreSlot2.Size = new System.Drawing.Size(20, 20);
            this.textSensoreSlot2.TabIndex = 30;
            this.textSensoreSlot2.TextChanged += new System.EventHandler(this.textSensoreSlot2_TextChanged);
            // 
            // textSensoreSlot1
            // 
            this.textSensoreSlot1.Location = new System.Drawing.Point(131, 226);
            this.textSensoreSlot1.Name = "textSensoreSlot1";
            this.textSensoreSlot1.Size = new System.Drawing.Size(20, 20);
            this.textSensoreSlot1.TabIndex = 29;
            this.textSensoreSlot1.TextChanged += new System.EventHandler(this.textSensoreSlot1_TextChanged);
            // 
            // textSensoreLivello3
            // 
            this.textSensoreLivello3.Location = new System.Drawing.Point(131, 201);
            this.textSensoreLivello3.Name = "textSensoreLivello3";
            this.textSensoreLivello3.Size = new System.Drawing.Size(20, 20);
            this.textSensoreLivello3.TabIndex = 28;
            this.textSensoreLivello3.TextChanged += new System.EventHandler(this.textSensoreLivello3_TextChanged);
            // 
            // textSensoreLivello2
            // 
            this.textSensoreLivello2.Location = new System.Drawing.Point(131, 175);
            this.textSensoreLivello2.Name = "textSensoreLivello2";
            this.textSensoreLivello2.Size = new System.Drawing.Size(20, 20);
            this.textSensoreLivello2.TabIndex = 27;
            this.textSensoreLivello2.TextChanged += new System.EventHandler(this.textSensoreLivello2_TextChanged);
            // 
            // textSensoreLivello1
            // 
            this.textSensoreLivello1.Location = new System.Drawing.Point(131, 149);
            this.textSensoreLivello1.Name = "textSensoreLivello1";
            this.textSensoreLivello1.Size = new System.Drawing.Size(20, 20);
            this.textSensoreLivello1.TabIndex = 26;
            this.textSensoreLivello1.TextChanged += new System.EventHandler(this.textSensoreLivello1_TextChanged);
            // 
            // textSensoreLivello0
            // 
            this.textSensoreLivello0.Location = new System.Drawing.Point(131, 124);
            this.textSensoreLivello0.Name = "textSensoreLivello0";
            this.textSensoreLivello0.Size = new System.Drawing.Size(20, 20);
            this.textSensoreLivello0.TabIndex = 25;
            this.textSensoreLivello0.TextChanged += new System.EventHandler(this.textSensoreLivello0_TextChanged);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label48.Location = new System.Drawing.Point(5, 309);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(70, 13);
            this.label48.TabIndex = 24;
            this.label48.Text = "SensoreSlot4";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label47.Location = new System.Drawing.Point(5, 286);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(70, 13);
            this.label47.TabIndex = 23;
            this.label47.Text = "SensoreSlot3";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label46.Location = new System.Drawing.Point(5, 258);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(70, 13);
            this.label46.TabIndex = 22;
            this.label46.Text = "SensoreSlot2";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label45.Location = new System.Drawing.Point(5, 229);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(70, 13);
            this.label45.TabIndex = 21;
            this.label45.Text = "SensoreSlot1";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label44.Location = new System.Drawing.Point(5, 204);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(82, 13);
            this.label44.TabIndex = 20;
            this.label44.Text = "SensoreLivello3";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label43.Location = new System.Drawing.Point(3, 175);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(82, 13);
            this.label43.TabIndex = 19;
            this.label43.Text = "SensoreLivello2";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label42.Location = new System.Drawing.Point(3, 153);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(82, 13);
            this.label42.TabIndex = 18;
            this.label42.Text = "SensoreLivello1";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label40.Location = new System.Drawing.Point(3, 127);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(82, 13);
            this.label40.TabIndex = 17;
            this.label40.Text = "SensoreLivello0";
            // 
            // textAgvInPos
            // 
            this.textAgvInPos.Location = new System.Drawing.Point(131, 63);
            this.textAgvInPos.Name = "textAgvInPos";
            this.textAgvInPos.Size = new System.Drawing.Size(20, 20);
            this.textAgvInPos.TabIndex = 16;
            this.textAgvInPos.TextChanged += new System.EventHandler(this.textAgvInPos_TextChanged);
            // 
            // textLiftInPos
            // 
            this.textLiftInPos.Location = new System.Drawing.Point(131, 89);
            this.textLiftInPos.Name = "textLiftInPos";
            this.textLiftInPos.Size = new System.Drawing.Size(20, 20);
            this.textLiftInPos.TabIndex = 15;
            this.textLiftInPos.TextChanged += new System.EventHandler(this.textLiftInPos_TextChanged);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label41.Location = new System.Drawing.Point(8, 96);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(48, 13);
            this.label41.TabIndex = 13;
            this.label41.Text = "LiftInPos";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label39.Location = new System.Drawing.Point(8, 69);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(49, 13);
            this.label39.TabIndex = 11;
            this.label39.Text = "AgvInLift";
            // 
            // textMacchinaInAGV
            // 
            this.textMacchinaInAGV.Location = new System.Drawing.Point(131, 31);
            this.textMacchinaInAGV.Name = "textMacchinaInAGV";
            this.textMacchinaInAGV.Size = new System.Drawing.Size(20, 20);
            this.textMacchinaInAGV.TabIndex = 10;
            this.textMacchinaInAGV.TextChanged += new System.EventHandler(this.textMacchinaInAGV_TextChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label38.Location = new System.Drawing.Point(5, 38);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(85, 13);
            this.label38.TabIndex = 9;
            this.label38.Text = "MacchinaInAGV";
            // 
            // textMacchinaInEntrance
            // 
            this.textMacchinaInEntrance.Location = new System.Drawing.Point(131, 5);
            this.textMacchinaInEntrance.Name = "textMacchinaInEntrance";
            this.textMacchinaInEntrance.Size = new System.Drawing.Size(20, 20);
            this.textMacchinaInEntrance.TabIndex = 8;
            this.textMacchinaInEntrance.TextChanged += new System.EventHandler(this.textMacchinaInEntrance_TextChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label37.Location = new System.Drawing.Point(5, 11);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(106, 13);
            this.label37.TabIndex = 7;
            this.label37.Text = "MacchinaInEntrance";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Alarms AGV:";
            // 
            // picturePark
            // 
            this.picturePark.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.picturePark.Location = new System.Drawing.Point(-13, 191);
            this.picturePark.Name = "picturePark";
            this.picturePark.Size = new System.Drawing.Size(183, 121);
            this.picturePark.TabIndex = 0;
            this.picturePark.TabStop = false;
            // 
            // simulationAGV
            // 
            this.simulationAGV.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.simulationAGV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.simulationAGV.Controls.Add(this.pictureSensor);
            this.simulationAGV.Controls.Add(this.pictureBox19);
            this.simulationAGV.Controls.Add(this.pictureBox18);
            this.simulationAGV.Controls.Add(this.label7);
            this.simulationAGV.Controls.Add(this.picturePark);
            this.simulationAGV.Location = new System.Drawing.Point(663, 388);
            this.simulationAGV.Name = "simulationAGV";
            this.simulationAGV.Size = new System.Drawing.Size(164, 331);
            this.simulationAGV.TabIndex = 1;
            // 
            // pictureSensor
            // 
            this.pictureSensor.BackColor = System.Drawing.Color.Black;
            this.pictureSensor.Location = new System.Drawing.Point(70, 183);
            this.pictureSensor.Name = "pictureSensor";
            this.pictureSensor.Size = new System.Drawing.Size(20, 120);
            this.pictureSensor.TabIndex = 2;
            this.pictureSensor.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.Gray;
            this.pictureBox19.Location = new System.Drawing.Point(82, 191);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(20, 120);
            this.pictureBox19.TabIndex = 9;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.Gray;
            this.pictureBox18.Location = new System.Drawing.Point(58, 191);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(20, 120);
            this.pictureBox18.TabIndex = 8;
            this.pictureBox18.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Simulation AGV:";
            // 
            // TimerLoadAGV
            // 
            this.TimerLoadAGV.Interval = 10;
            this.TimerLoadAGV.Tick += new System.EventHandler(this.TimerLoadAGV_Tick);
            // 
            // TimerUnloadAGV
            // 
            this.TimerUnloadAGV.Interval = 10;
            this.TimerUnloadAGV.Tick += new System.EventHandler(this.TimerUnloadAGV_Tick);
            // 
            // TimerPosizionaSuLift
            // 
            this.TimerPosizionaSuLift.Interval = 1;
            this.TimerPosizionaSuLift.Tick += new System.EventHandler(this.TimerPosizionaSuLift_Tick);
            // 
            // TimerRiposizionaAGV
            // 
            this.TimerRiposizionaAGV.Interval = 10;
            this.TimerRiposizionaAGV.Tick += new System.EventHandler(this.TimerRiposizionaAGV_Tick);
            // 
            // timerSali
            // 
            this.timerSali.Interval = 50;
            this.timerSali.Tick += new System.EventHandler(this.timerSali_Tick);
            // 
            // TimerRichiestaScarico
            // 
            this.TimerRichiestaScarico.Interval = 20000;
            this.TimerRichiestaScarico.Tick += new System.EventHandler(this.TimerRichiestaScarico_Tick);
            // 
            // timerSensoriSlot
            // 
            this.timerSensoriSlot.Interval = 25;
            this.timerSensoriSlot.Tick += new System.EventHandler(this.timerSensoriSlot_Tick);
            // 
            // timerRiposizionaLift
            // 
            this.timerRiposizionaLift.Interval = 10;
            this.timerRiposizionaLift.Tick += new System.EventHandler(this.timerRiposizionaLift_Tick);
            // 
            // timerVaiDx
            // 
            this.timerVaiDx.Interval = 30;
            this.timerVaiDx.Tick += new System.EventHandler(this.timerVaiDx_Tick);
            // 
            // timerVaiSx
            // 
            this.timerVaiSx.Interval = 30;
            this.timerVaiSx.Tick += new System.EventHandler(this.timerVaiSx_Tick);
            // 
            // timerPortaViaMacchina
            // 
            this.timerPortaViaMacchina.Interval = 75;
            this.timerPortaViaMacchina.Tick += new System.EventHandler(this.timerPortaViaMacchina_Tick);
            // 
            // timerDelayLevel
            // 
            this.timerDelayLevel.Interval = 500;
            // 
            // GarageVerticaleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(1009, 746);
            this.Controls.Add(this.simulationAGV);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.simulation);
            this.Name = "GarageVerticaleForm";
            this.Text = "GarageVerticaleForm";
            this.Load += new System.EventHandler(this.GarageVerticaleForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Park04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Park31)).EndInit();
            this.simulation.ResumeLayout(false);
            this.simulation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture0B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture2D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture2C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture2B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture1D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture1C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture1B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture3D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture3C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture3B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture3A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture2A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLift)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture1A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureAgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GateExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GateEntrance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picturePark)).EndInit();
            this.simulationAGV.ResumeLayout(false);
            this.simulationAGV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureSensor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textStart;
        private System.Windows.Forms.TextBox textReset;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Button Start;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button AddCar;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel simulation;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox picture1A;
        private System.Windows.Forms.PictureBox pictureAgv;
        private System.Windows.Forms.PictureBox pictureLift;
        private System.Windows.Forms.Timer MasterTimer;
        private System.Windows.Forms.Timer TimerDelay;
        private System.Windows.Forms.Timer WatchDog;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox picture0B;
        private System.Windows.Forms.PictureBox picture1B;
        private System.Windows.Forms.PictureBox picture3D;
        private System.Windows.Forms.PictureBox picture3C;
        private System.Windows.Forms.PictureBox picture3B;
        private System.Windows.Forms.PictureBox picture3A;
        private System.Windows.Forms.PictureBox picture2D;
        private System.Windows.Forms.PictureBox picture2C;
        private System.Windows.Forms.PictureBox picture2B;
        private System.Windows.Forms.PictureBox picture2A;
        private System.Windows.Forms.PictureBox picture1D;
        private System.Windows.Forms.PictureBox picture1C;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox pictureBox0A;
        private System.Windows.Forms.PictureBox pictureBox0D;
        private System.Windows.Forms.PictureBox pictureBox0C;
        private System.Windows.Forms.PictureBox pictureBox0B;
        private System.Windows.Forms.PictureBox pictureBox1C;
        private System.Windows.Forms.PictureBox pictureBox1B;
        private System.Windows.Forms.PictureBox pictureBox1A;
        private System.Windows.Forms.PictureBox pictureBox1D;
        private System.Windows.Forms.PictureBox pictureBox2D;
        private System.Windows.Forms.PictureBox pictureBox2C;
        private System.Windows.Forms.PictureBox pictureBox2B;
        private System.Windows.Forms.PictureBox pictureBox2A;
        private System.Windows.Forms.PictureBox pictureBox3D;
        private System.Windows.Forms.PictureBox pictureBox3C;
        private System.Windows.Forms.PictureBox pictureBox3B;
        private System.Windows.Forms.PictureBox pictureBox3A;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox GateExit;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox GateEntrance;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Timer TimerAutoLift;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Timer TimerAutoUnload;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Timer TimerCausalEntrance;
        private System.Windows.Forms.Timer TimerEntranceToLift;
        private System.Windows.Forms.Label labelPositions;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox picturePark;
        private System.Windows.Forms.Panel simulationAGV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureSensor;
        private System.Windows.Forms.Timer TimerLoadAGV;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Timer TimerUnloadAGV;
        private System.Windows.Forms.Button buttonConnection;
        private System.Windows.Forms.TextBox textConnection;
        private System.Windows.Forms.TextBox textComandoPortaViaMacchina;
        private System.Windows.Forms.TextBox textComandoPosizionaMacchina;
        private System.Windows.Forms.TextBox textComandoRiposizionaLift;
        private System.Windows.Forms.TextBox textComandoRiposizionaAgv;
        private System.Windows.Forms.TextBox textComandoScarica;
        private System.Windows.Forms.TextBox textComandoCarica;
        private System.Windows.Forms.TextBox textComandoVaiSx;
        private System.Windows.Forms.TextBox textComandoVaiDx;
        private System.Windows.Forms.TextBox textComandoSali;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textMacchinaInEntrance;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textMacchinaInAGV;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textLiftInPos;
        private System.Windows.Forms.TextBox textAgvInPos;
        private System.Windows.Forms.Timer TimerPosizionaSuLift;
        private System.Windows.Forms.TextBox textSensoreSlot4;
        private System.Windows.Forms.TextBox textSensoreSlot3;
        private System.Windows.Forms.TextBox textSensoreSlot2;
        private System.Windows.Forms.TextBox textSensoreSlot1;
        private System.Windows.Forms.TextBox textSensoreLivello3;
        private System.Windows.Forms.TextBox textSensoreLivello2;
        private System.Windows.Forms.TextBox textSensoreLivello1;
        private System.Windows.Forms.TextBox textSensoreLivello0;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Timer TimerRiposizionaAGV;
        private System.Windows.Forms.Timer timerSali;
        private System.Windows.Forms.Timer TimerRichiestaScarico;
        private System.Windows.Forms.TextBox textDeviScaricare;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Timer timerSensoriLivelli;
        private System.Windows.Forms.Timer timerSensoriSlot;
        private System.Windows.Forms.Timer timerRiposizionaLift;
        private System.Windows.Forms.Timer timerVaiDx;
        private System.Windows.Forms.Timer timerVaiSx;
        private System.Windows.Forms.TextBox textComandoAllarme;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Timer timerPortaViaMacchina;
        private System.Windows.Forms.Timer timerDelayLevel;
        private System.Windows.Forms.Label TimeWatchDog;
        private System.Windows.Forms.TextBox textTimeWatchDog;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.TextBox textGuasto;
        private System.Windows.Forms.Button buttonGuastoAscensore;
        private System.Windows.Forms.TextBox textStop;
        private System.Windows.Forms.Button buttonRipara;
        private System.Windows.Forms.PictureBox Park04;
        private System.Windows.Forms.PictureBox Park03;
        private System.Windows.Forms.PictureBox Park02;
        private System.Windows.Forms.PictureBox Park01;
        private System.Windows.Forms.PictureBox Park14;
        private System.Windows.Forms.PictureBox Park13;
        private System.Windows.Forms.PictureBox Park12;
        private System.Windows.Forms.PictureBox Park11;
        private System.Windows.Forms.PictureBox Park23;
        private System.Windows.Forms.PictureBox Park24;
        private System.Windows.Forms.PictureBox Park22;
        private System.Windows.Forms.PictureBox Park21;
        private System.Windows.Forms.PictureBox Park34;
        private System.Windows.Forms.PictureBox Park33;
        private System.Windows.Forms.PictureBox Park32;
        private System.Windows.Forms.PictureBox Park31;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textParkFull;
        private System.Windows.Forms.TextBox textScaricoOff;
        private System.Windows.Forms.TextBox textScaricoOn;
        private System.Windows.Forms.Button buttonOff;
        private System.Windows.Forms.Button buttonOn;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textTimeAct;
        private System.Windows.Forms.Label label20;
    }
}

